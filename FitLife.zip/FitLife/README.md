# FitLife — Sistema de Gestão de Academia

Trabalho da P2 de Programação Orientada a Objetos (Java 17+, console).

## Rodar no IntelliJ
1. File → Open → escolha esta pasta (FitLife).
2. Se pedir, escolha um JDK 17 ou mais novo (File → Project Structure → SDK).
3. No canto superior direito, escolha a configuração **FitLife** e clique no ▶ verde
   (ou abra src/fitlife/Main.java e clique no ▶ ao lado do main).
4. Na primeira vez, digite 6 para carregar os dados de exemplo.

## Rodar pelo terminal (Windows, PowerShell)
    javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
    java -cp out fitlife.Main

Os dados ficam em dados/*.csv e os relatórios em relatorios/*.txt (criados automaticamente).
