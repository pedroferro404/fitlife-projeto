package fitlife.util;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

/** Utilitário de formatação no padrão brasileiro (datas, horas e dinheiro). */
public final class Formatos {

    public static final Locale PT_BR = Locale.forLanguageTag("pt-BR");
    public static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");
    public static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    public static final DateTimeFormatter MES = DateTimeFormatter.ofPattern("MM/yyyy");

    private Formatos() {
        // classe utilitária: não deve ser instanciada
    }

    public static String moeda(double valor) {
        return String.format(PT_BR, "R$ %,.2f", valor);
    }

    public static String numero(double valor) {
        return String.format(PT_BR, "%.1f", valor);
    }

    public static String data(LocalDate data) {
        return data.format(DATA);
    }

    public static String hora(LocalTime hora) {
        return hora.format(HORA);
    }

    public static String dataHora(LocalDateTime dataHora) {
        return dataHora.format(DATA_HORA);
    }

    public static String mes(YearMonth mes) {
        return mes.format(MES);
    }

    public static String diaSemana(DayOfWeek dia) {
        String nome = dia.getDisplayName(TextStyle.FULL, PT_BR);
        return Character.toUpperCase(nome.charAt(0)) + nome.substring(1);
    }
}
