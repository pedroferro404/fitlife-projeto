package fitlife.persistencia;

import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.AulaVip;
import fitlife.modelo.AvaliacaoFisica;
import fitlife.modelo.Equipamento;
import fitlife.modelo.Pagamento;
import fitlife.modelo.Plano;
import fitlife.modelo.Presenca;
import fitlife.modelo.Professor;
import fitlife.modelo.RegistroTreino;
import fitlife.modelo.Reserva;
import fitlife.modelo.StatusEquipamento;
import fitlife.modelo.TipoModalidade;
import fitlife.servico.Academia;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
* Salva e carrega todos os dados em arquivos CSV (separador ";") na pasta "dados/".
* Tratamento de erros:
* - arquivo ausente: é ignorado (sistema começa vazio);
* - linha corrompida: é pulada com aviso, sem derrubar o sistema;
* - gravação: escreve num .tmp e depois substitui, para não corromper o arquivo original.
*/
public class Persistencia {

    private static final String SEP = ";";
    private final Path pastaDados;
    private final Path pastaRelatorios;

    public Persistencia(Path pastaDados, Path pastaRelatorios) {
        this.pastaDados = pastaDados;
        this.pastaRelatorios = pastaRelatorios;
    }

    // =====================================================================
    // SALVAR
    // =====================================================================

    public boolean salvar(Academia a) {
        try {
            Files.createDirectories(pastaDados);
            escrever("professores.csv", "id;nome;telefone;especialidade",
                    a.getProfessores().stream().map(p -> linha(p.getId(), p.getNome(), p.getTelefone(),
                            p.getEspecialidade().name())).collect(Collectors.toList()));

            escrever("alunos.csv", "id;nome;telefone;plano;diaVencimento;dataMatricula",
                    a.getAlunos().stream().map(al -> linha(al.getId(), al.getNome(), al.getTelefone(),
                            al.getPlano().getCodigo(), al.getDiaVencimento(), al.getDataMatricula()))
                            .collect(Collectors.toList()));

            escrever("aulas.csv", "id;tipo;modalidade;professorId;dia;horario;vagas",
                    a.getAulas().stream().map(au -> linha(au.getId(), au instanceof AulaVip ? "VIP" : "REGULAR",
                                au.getModalidade().name(), au.getProfessor().getId(), au.getDiaSemana().name(),
                                au.getHorario(), au.getLimiteVagas())).collect(Collectors.toList()));

            List<String> inscricoes = new ArrayList<>();
            for (Aula au : a.getAulas()) {
                au.getInscritos().forEach(al -> inscricoes.add(linha(au.getId(), al.getId(), "INSCRITO")));
                au.getListaEspera().forEach(al -> inscricoes.add(linha(au.getId(), al.getId(), "ESPERA")));
            }
            escrever("inscricoes.csv", "aulaId;alunoId;situacao", inscricoes);

            escrever("equipamentos.csv", "id;nome;status",
                    a.getEquipamentos().stream().map(e -> linha(e.getId(), e.getNome(), e.getStatus().name()))
                            .collect(Collectors.toList()));

            escrever("reservas.csv", "id;equipamentoId;alunoId;inicio;fim",
                    a.getReservas().stream().map(r -> linha(r.getId(), r.getEquipamento().getId(),
                            r.getAluno().getId(), r.getInicio(), r.getFim())).collect(Collectors.toList()));

            List<String> presencas = new ArrayList<>();
            List<String> avaliacoes = new ArrayList<>();
            List<String> treinos = new ArrayList<>();
            for (Aluno al : a.getAlunos()) {
                al.getPresencas().forEach(p -> presencas.add(linha(al.getId(), p.getData(), p.getAulaId())));
                al.getAvaliacoes().forEach(av -> avaliacoes.add(linha(al.getId(), av.getData(), av.getPeso(),
                        av.getPercentualGordura())));
                al.getHistorico().forEach(t -> treinos.add(linha(al.getId(), t.getData(), t.getDescricao())));
            }
            escrever("presencas.csv", "alunoId;data;aulaId", presencas);
            escrever("avaliacoes.csv", "alunoId;data;peso;percentualGordura", avaliacoes);
            escrever("historico.csv", "alunoId;data;descricao", treinos);

            escrever("pagamentos.csv", "id;alunoId;alunoNome;plano;referencia;vencimento;dataPagamento;valorBase",
                    a.getPagamentos().stream().map(p -> linha(p.getId(), p.getAlunoId(), p.getAlunoNome(),
                            p.getPlano().getCodigo(), p.getReferencia(), p.getVencimento(), p.getDataPagamento(),
                            p.getValorBase())).collect(Collectors.toList()));
            return true;
        } catch (IOException e) {
            System.out.println("[AVISO] Não foi possível salvar os dados: " + e.getMessage());
            return false;
        }
    }

    private void escrever(String arquivo, String cabecalho, List<String> linhas) throws IOException {
        List<String> conteudo = new ArrayList<>();
        conteudo.add(cabecalho);
        conteudo.addAll(linhas);
        Path temporario = pastaDados.resolve(arquivo + ".tmp");
        Files.write(temporario, conteudo, StandardCharsets.UTF_8);
        Files.move(temporario, pastaDados.resolve(arquivo), StandardCopyOption.REPLACE_EXISTING);
    }

    /** Junta os campos com ";" e remove caracteres que quebrariam o CSV. */
    private static String linha(Object... campos) {
        return Arrays.stream(campos)
                .map(c -> String.valueOf(c).replace(SEP, ",").replace("\n", " ").replace("\r", " "))
                .collect(Collectors.joining(SEP));
    }

    // =====================================================================
    // CARREGAR
    // =====================================================================

    /** Carrega na ordem certa (professores antes de aulas, alunos antes de inscrições...). */
    public void carregar(Academia a) {
        int erros = 0;
        erros += ler("professores.csv", 4, c -> a.adicionarProfessor(new Professor(
                inteiro(c[0]), c[1], c[2], TipoModalidade.valueOf(c[3]))));

        erros += ler("alunos.csv", 6, c -> a.adicionarAluno(new Aluno(inteiro(c[0]), c[1], c[2],
                Plano.criar(c[3]), inteiro(c[4]), LocalDate.parse(c[5]))));

        erros += ler("aulas.csv", 7, c -> {
            int id = inteiro(c[0]);
            TipoModalidade modalidade = TipoModalidade.valueOf(c[2]);
            Professor professor = a.buscarProfessor(inteiro(c[3]));
            DayOfWeek dia = DayOfWeek.valueOf(c[4]);
            LocalTime hora = LocalTime.parse(c[5]);
            int vagas = inteiro(c[6]);
            a.adicionarAula("VIP".equals(c[1])
                    ? new AulaVip(id, modalidade, professor, dia, hora, vagas)
                    : new Aula(id, modalidade, professor, dia, hora, vagas));
        });

        erros += ler("inscricoes.csv", 3, c -> {
            Aula aula = a.buscarAula(inteiro(c[0]));
            Aluno aluno = a.buscarAluno(inteiro(c[1]));
            if ("ESPERA".equals(c[2])) {
                aula.restaurarEspera(aluno);
            } else {
                aula.restaurarInscrito(aluno);
            }
        });

        erros += ler("equipamentos.csv", 3, c -> a.adicionarEquipamento(new Equipamento(
                inteiro(c[0]), c[1], StatusEquipamento.valueOf(c[2]))));

        erros += ler("reservas.csv", 5, c -> a.adicionarReserva(new Reserva(inteiro(c[0]),
                a.buscarEquipamento(inteiro(c[1])), a.buscarAluno(inteiro(c[2])),
                LocalDateTime.parse(c[3]), LocalDateTime.parse(c[4]))));

        erros += ler("presencas.csv", 3, c -> a.buscarAluno(inteiro(c[0]))
                .registrarPresenca(new Presenca(LocalDate.parse(c[1]), inteiro(c[2]))));

        erros += ler("avaliacoes.csv", 4, c -> a.buscarAluno(inteiro(c[0])).adicionarAvaliacao(
                new AvaliacaoFisica(LocalDate.parse(c[1]), decimal(c[2]), decimal(c[3]))));

        erros += ler("historico.csv", 3, c -> a.buscarAluno(inteiro(c[0])).adicionarRegistro(
                new RegistroTreino(LocalDate.parse(c[1]), c[2])));

        erros += ler("pagamentos.csv", 8, c -> a.adicionarPagamento(new Pagamento(inteiro(c[0]), inteiro(c[1]),
                c[2], Plano.criar(c[3]), YearMonth.parse(c[4]), LocalDate.parse(c[5]), LocalDate.parse(c[6]),
                decimal(c[7]))));

        if (erros > 0) {
            System.out.println("[AVISO] " + erros + " registro(s) com problema foram ignorados ao carregar.");
        }
    }

    /**
    * Lê um CSV linha a linha. Cada linha inválida gera um aviso e é pulada,
    * assim um arquivo editado à mão errado não derruba o sistema.
    */
    private int ler(String arquivo, int camposMinimos, Consumer<String[]> conversor) {
        Path caminho = pastaDados.resolve(arquivo);
        if (!Files.exists(caminho)) {
            return 0;
        }
        List<String> linhas;
        try {
            linhas = Files.readAllLines(caminho, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("[AVISO] Não foi possível ler " + arquivo + ": " + e.getMessage());
            return 1;
        }
        int erros = 0;
        for (int i = 1; i < linhas.size(); i++) { // linha 0 é o cabeçalho
            String texto = linhas.get(i);
            if (texto.isBlank()) {
                continue;
            }
            try {
                String[] campos = texto.split(SEP, -1);
                if (campos.length < camposMinimos) {
                    throw new IllegalArgumentException("esperado " + camposMinimos + " campos");
                }
                conversor.accept(campos);
            } catch (RuntimeException e) {
                erros++;
                System.out.printf("[AVISO] %s, linha %d ignorada (%s)%n", arquivo, i + 1, e.getMessage());
            }
        }
        return erros;
    }

    private static int inteiro(String s) {
        return Integer.parseInt(s.trim());
    }

    private static double decimal(String s) {
        return Double.parseDouble(s.trim().replace(',', '.'));
    }

    // =====================================================================
    // RELATÓRIOS EM ARQUIVO
    // =====================================================================

    /** Salva um relatório .txt em "relatorios/" e devolve o caminho (ou null se falhar). */
    public Path salvarRelatorio(String nomeArquivo, String conteudo) {
        try {
            Files.createDirectories(pastaRelatorios);
            Path destino = pastaRelatorios.resolve(nomeArquivo);
            Files.writeString(destino, conteudo, StandardCharsets.UTF_8);
            return destino;
        } catch (IOException e) {
            System.out.println("[AVISO] Não foi possível salvar o relatório: " + e.getMessage());
            return null;
        }
    }
}
