package fitlife.ui;

import fitlife.excecao.EntradaEncerradaException;
import fitlife.util.Formatos;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
* Leitura segura do teclado. Todos os métodos repetem a pergunta até
* receber um valor válido — o sistema nunca quebra por digitação errada.
*/
public final class Console {

    private static final Scanner ENTRADA = new Scanner(System.in);

    private Console() {
    }

    public static String lerLinha(String pergunta) {
        System.out.print(pergunta);
        if (!ENTRADA.hasNextLine()) {
            throw new EntradaEncerradaException();
        }
        return ENTRADA.nextLine().trim();
    }

    public static String lerTexto(String pergunta) {
        while (true) {
            String texto = lerLinha(pergunta);
            if (!texto.isEmpty()) {
                return texto;
            }
            erro("Este campo é obrigatório.");
        }
    }

    public static int lerInt(String pergunta, int minimo, int maximo) {
        while (true) {
            String texto = lerLinha(pergunta);
            try {
                int valor = Integer.parseInt(texto);
                if (valor >= minimo && valor <= maximo) {
                    return valor;
                }
                erro("Digite um número entre " + minimo + " e " + maximo + ".");
            } catch (NumberFormatException e) {
                erro("\"" + texto + "\" não é um número inteiro válido.");
            }
        }
    }

    /** Aceita vírgula ou ponto como separador decimal. */
    public static double lerDouble(String pergunta, double minimo, double maximo) {
        while (true) {
            String texto = lerLinha(pergunta).replace(',', '.');
            try {
                double valor = Double.parseDouble(texto);
                if (valor >= minimo && valor <= maximo) {
                    return valor;
                }
                erro("Digite um valor entre " + minimo + " e " + maximo + ".");
            } catch (NumberFormatException e) {
                erro("\"" + texto + "\" não é um número válido.");
            }
        }
    }

    public static boolean confirmar(String pergunta) {
        while (true) {
            String resposta = lerLinha(pergunta + " (s/n): ").toLowerCase();
            if (resposta.equals("s") || resposta.equals("sim")) {
                return true;
            }
            if (resposta.equals("n") || resposta.equals("nao") || resposta.equals("não")) {
                return false;
            }
            erro("Responda com s ou n.");
        }
    }

    /** Data no formato dd/MM/aaaa; Enter vazio = hoje. */
    public static LocalDate lerData(String pergunta) {
        while (true) {
            String texto = lerLinha(pergunta + " [dd/MM/aaaa, Enter = hoje]: ");
            if (texto.isEmpty()) {
                return LocalDate.now();
            }
            try {
                return LocalDate.parse(texto, Formatos.DATA);
            } catch (DateTimeParseException e) {
                erro("Data inválida. Exemplo: 25/11/2026");
            }
        }
    }

    public static LocalTime lerHora(String pergunta) {
        while (true) {
            String texto = lerLinha(pergunta + " [HH:mm]: ");
            try {
                return LocalTime.parse(texto, Formatos.HORA);
            } catch (DateTimeParseException e) {
                erro("Horário inválido. Exemplo: 07:30");
            }
        }
    }

    public static LocalDateTime lerDataHora(String pergunta) {
        while (true) {
            String texto = lerLinha(pergunta + " [dd/MM/aaaa HH:mm]: ");
            try {
                return LocalDateTime.parse(texto, Formatos.DATA_HORA);
            } catch (DateTimeParseException e) {
                erro("Data/hora inválida. Exemplo: 26/11/2026 07:00");
            }
        }
    }

    /** Mês no formato MM/aaaa; Enter vazio = mês atual. */
    public static YearMonth lerMes(String pergunta) {
        while (true) {
            String texto = lerLinha(pergunta + " [MM/aaaa, Enter = mês atual]: ");
            if (texto.isEmpty()) {
                return YearMonth.now();
            }
            try {
                return YearMonth.parse(texto, Formatos.MES);
            } catch (DateTimeParseException e) {
                erro("Mês inválido. Exemplo: 11/2026");
            }
        }
    }

    public static DayOfWeek lerDiaSemana(String pergunta) {
        DayOfWeek[] dias = DayOfWeek.values();
        for (int i = 0; i < dias.length; i++) {
            System.out.printf(" %d. %s%n", i + 1, Formatos.diaSemana(dias[i]));
        }
        return dias[lerInt(pergunta, 1, dias.length) - 1];
    }

    /** Mostra as opções de qualquer enum numeradas e devolve a escolhida. */
    public static <E extends Enum<E>> E escolher(String pergunta, E[] opcoes) {
        for (int i = 0; i < opcoes.length; i++) {
            System.out.printf(" %d. %s%n", i + 1, opcoes[i]);
        }
        return opcoes[lerInt(pergunta, 1, opcoes.length) - 1];
    }

    public static void titulo(String texto) {
        System.out.println();
        System.out.println("=".repeat(64));
        System.out.println(" " + texto);
        System.out.println("=".repeat(64));
    }

    public static void sucesso(String mensagem) {
        System.out.println("[OK] " + mensagem);
    }

    public static void erro(String mensagem) {
        System.out.println("[ERRO] " + mensagem);
    }

    public static void alerta(String mensagem) {
        System.out.println("[ALERTA] " + mensagem);
    }
}
