package fitlife.ui;

import fitlife.excecao.AcademiaException;
import fitlife.excecao.EntradaEncerradaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.AvaliacaoFisica;
import fitlife.modelo.Equipamento;
import fitlife.modelo.Pagamento;
import fitlife.modelo.Plano;
import fitlife.modelo.Professor;
import fitlife.modelo.RegistroTreino;
import fitlife.modelo.Reserva;
import fitlife.modelo.SituacaoInscricao;
import fitlife.modelo.TipoModalidade;
import fitlife.persistencia.Persistencia;
import fitlife.servico.Academia;
import fitlife.servico.AlunoService;
import fitlife.servico.AulaService;
import fitlife.servico.DadosExemplo;
import fitlife.servico.EquipamentoService;
import fitlife.servico.FinanceiroService;
import fitlife.servico.HistoricoService;
import fitlife.util.Formatos;

import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.List;

/**
* Interface de console. Só conversa com o usuário e chama os serviços;
* nenhuma regra de negócio fica aqui (separação de responsabilidades).
*/
public class Menu {

    private final Academia academia;
    private final Persistencia persistencia;
    private final AulaService aulaService;
    private final AlunoService alunoService;
    private final EquipamentoService equipamentoService;
    private final HistoricoService historicoService;
    private final FinanceiroService financeiroService;

    public Menu(Academia academia, Persistencia persistencia) {
        this.academia = academia;
        this.persistencia = persistencia;
        this.aulaService = new AulaService(academia);
        this.alunoService = new AlunoService(academia);
        this.equipamentoService = new EquipamentoService(academia);
        this.historicoService = new HistoricoService(academia);
        this.financeiroService = new FinanceiroService(academia);
    }

    public void executar() {
        System.out.println("\n FITLIFE ACADEMIA - Sistema de Gestão");
        try {
            mostrarResumoInicial();
            int opcao;
            do {
                Console.titulo("MENU PRINCIPAL");
                System.out.println(" 1. Modalidades, horários e professores");
                System.out.println(" 2. Alunos, planos e frequência");
                System.out.println(" 3. Equipamentos e reservas");
                System.out.println(" 4. Histórico e avaliações físicas");
                System.out.println(" 5. Pagamentos e relatórios financeiros");
                System.out.println(" 6. Carregar dados de exemplo");
                System.out.println(" 0. Sair");
                opcao = Console.lerInt("Opção: ", 0, 6);
                switch (opcao) {
                    case 1 -> menuAulas();
                    case 2 -> menuAlunos();
                    case 3 -> menuEquipamentos();
                    case 4 -> menuHistorico();
                    case 5 -> menuFinanceiro();
                    case 6 -> carregarExemplo();
                    default -> { }
                }
            } while (opcao != 0);
        } catch (EntradaEncerradaException e) {
            System.out.println("\nEntrada encerrada.");
        }
        if (persistencia.salvar(academia)) {
            System.out.println("Dados salvos em dados/. Até logo!");
        }
    }

    // =====================================================================
    // Execução protegida: qualquer erro de regra vira mensagem, nunca derruba o sistema
    // =====================================================================

    /** Ação que altera dados: executa e salva em seguida. */
    private void alterar(Runnable acao) {
        try {
            acao.run();
            persistencia.salvar(academia);
        } catch (AcademiaException | IllegalArgumentException e) {
            Console.erro(e.getMessage());
        }
    }

    /** Ação só de consulta. */
    private void consultar(Runnable acao) {
        try {
            acao.run();
        } catch (AcademiaException | IllegalArgumentException e) {
            Console.erro(e.getMessage());
        }
    }

    private void mostrarResumoInicial() {
        if (academia.isVazia()) {
            System.out.println(" Nenhum dado encontrado. Use a opção 6 para carregar dados de exemplo.");
            return;
        }
        System.out.printf(" %d alunos, %d aulas, %d equipamentos carregados.%n",
                academia.getAlunos().size(), academia.getAulas().size(), academia.getEquipamentos().size());
        int baixa = alunoService.alunosComBaixaFrequencia(LocalDate.now()).size();
        if (baixa > 0) {
            Console.alerta(baixa + " aluno(s) com baixa frequência (menu 2 > opção 6).");
        }
    }

    private void carregarExemplo() {
        if (!academia.isVazia() && !Console.confirmar("Isso apaga os dados atuais. Continuar?")) {
            return;
        }
        alterar(() -> {
            // Os dados de exemplo passam pelos mesmos serviços, então respeitam todas as regras.
            new DadosExemplo(academia, aulaService, alunoService, equipamentoService,
                    historicoService, financeiroService).carregar();
            Console.sucesso("Dados de exemplo carregados.");
        });
    }

    // =====================================================================
    // 1. MODALIDADES, HORÁRIOS E PROFESSORES
    // =====================================================================

    private void menuAulas() {
        int opcao;
        do {
            Console.titulo("1. MODALIDADES, HORÁRIOS E PROFESSORES");
            System.out.println(" 1. Cadastrar professor");
            System.out.println(" 2. Listar professores");
            System.out.println(" 3. Cadastrar aula");
            System.out.println(" 4. Editar dia/horário/vagas de uma aula");
            System.out.println(" 5. Remover aula");
            System.out.println(" 6. Ver grade de aulas");
            System.out.println(" 7. Inscrever aluno em aula");
            System.out.println(" 8. Cancelar inscrição");
            System.out.println(" 9. Ver inscritos e lista de espera");
            System.out.println(" 0. Voltar");
            opcao = Console.lerInt("Opção: ", 0, 9);
            switch (opcao) {
                case 1 -> alterar(() -> {
                    String nome = Console.lerTexto("Nome: ");
                    String telefone = Console.lerLinha("Telefone: ");
                    TipoModalidade esp = Console.escolher("Especialidade: ", TipoModalidade.values());
                    Console.sucesso("Cadastrado: " + aulaService.cadastrarProfessor(nome, telefone, esp));
                });
                case 2 -> consultar(this::listarProfessores);
                case 3 -> alterar(() -> {
                    TipoModalidade modalidade = Console.escolher("Modalidade: ", TipoModalidade.values());
                    Professor professor = escolherProfessor();
                    DayOfWeek dia = Console.lerDiaSemana("Dia da semana: ");
                    LocalTime hora = Console.lerHora("Horário");
                    int vagas = Console.lerInt("Limite de vagas: ", 1, 100);
                    boolean vip = Console.confirmar("Aula especial exclusiva para VIP?");
                    Aula aula = aulaService.cadastrarAula(modalidade, professor.getId(), dia, hora, vagas, vip);
                    Console.sucesso("Aula cadastrada: " + aula);
                });
                case 4 -> alterar(() -> {
                    Aula aula = escolherAula();
                    DayOfWeek dia = Console.lerDiaSemana("Novo dia: ");
                    LocalTime hora = Console.lerHora("Novo horário");
                    int vagas = Console.lerInt("Novo limite de vagas: ", 1, 100);
                    aulaService.editarAula(aula.getId(), dia, hora, vagas);
                    Console.sucesso("Aula atualizada: " + aula);
                });
                case 5 -> alterar(() -> {
                    Aula aula = escolherAula();
                    if (Console.confirmar("Remover a aula #" + aula.getId() + " e todas as inscrições?")) {
                        aulaService.removerAula(aula.getId());
                        Console.sucesso("Aula removida.");
                    }
                });
                case 6 -> consultar(this::listarGrade);
                case 7 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    Aula aula = escolherAula();
                    SituacaoInscricao situacao = aulaService.inscrever(aluno.getId(), aula.getId());
                    if (situacao == SituacaoInscricao.INSCRITO) {
                        Console.sucesso(aluno.getNome() + " inscrito(a) na aula #" + aula.getId() + ".");
                    } else {
                        int posicao = aula.getListaEspera().indexOf(aluno) + 1;
                        Console.alerta("Turma lotada. " + aluno.getNome() + " entrou na lista de espera na posição "
                                + posicao + (aluno.isVip() ? " (prioridade VIP)." : "."));
                    }
                });
                case 8 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    Aula aula = escolherAula();
                    Aluno promovido = aulaService.cancelarInscricao(aluno.getId(), aula.getId());
                    Console.sucesso("Inscrição cancelada.");
                    if (promovido != null) {
                        Console.sucesso(promovido.getNome() + " saiu da lista de espera e foi inscrito(a).");
                    }
                });
                case 9 -> consultar(() -> {
                    Aula aula = escolherAula();
                    System.out.println(aula);
                    System.out.println(" Inscritos:");
                    // mostra cada inscrito com a frequência dele NESTA aula
                    for (Aluno a : aula.getInscritos()) {
                        System.out.printf("    - %-18s (%s) · %d presença(s) nesta aula%n",
                                a.getNome(), a.getPlano().getNome(), a.presencasNaAula(aula.getId()));
                    }
                    System.out.println(" Lista de espera:");
                    if (aula.getListaEspera().isEmpty()) {
                        System.out.println("    (vazia)");
                    }
                    List<Aluno> espera = aula.getListaEspera();
                    for (int i = 0; i < espera.size(); i++) {
                        System.out.printf("    %d. %s (%s)%n", i + 1, espera.get(i).getNome(), espera.get(i).getPlano().getNome());
                    }
                });
                default -> { }
            }
        } while (opcao != 0);
    }

    // =====================================================================
    // 2. ALUNOS, PLANOS E FREQUÊNCIA
    // =====================================================================

    private void menuAlunos() {
        int opcao;
        do {
            Console.titulo("2. ALUNOS, PLANOS E FREQUÊNCIA");
            System.out.println(" 1. Cadastrar aluno");
            System.out.println(" 2. Listar alunos");
            System.out.println(" 3. Trocar plano");
            System.out.println(" 4. Remover aluno");
            System.out.println(" 5. Registrar presença");
            System.out.println(" 6. Alerta de baixa frequência");
            System.out.println(" 7. Ver planos disponíveis");
            System.out.println(" 0. Voltar");
            opcao = Console.lerInt("Opção: ", 0, 7);
            switch (opcao) {
                case 1 -> alterar(() -> {
                    String nome = Console.lerTexto("Nome: ");
                    String telefone = Console.lerLinha("Telefone: ");
                    Plano plano = escolherPlano();
                    int dia = Console.lerInt("Dia de vencimento (1 a 28): ", 1, 28);
                    Console.sucesso("Cadastrado: " + alunoService.cadastrarAluno(nome, telefone, plano, dia));
                });
                case 2 -> consultar(this::listarAlunos);
                case 3 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    Plano plano = escolherPlano();
                    alunoService.trocarPlano(aluno.getId(), plano);
                    Console.sucesso(aluno.getNome() + " agora está no plano " + plano.getNome() + ".");
                });
                case 4 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    if (Console.confirmar("Remover " + aluno.getNome() + " (inscrições e reservas também)?")) {
                        alunoService.removerAluno(aluno.getId());
                        Console.sucesso("Aluno removido. Os pagamentos continuam no histórico financeiro.");
                    }
                });
                case 5 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    List<Aula> aulas = academia.aulasDoAluno(aluno);
                    if (aulas.isEmpty()) {
                        throw new AcademiaException(aluno.getNome() + " não está inscrito(a) em nenhuma aula.");
                    }
                    aulas.forEach(a -> System.out.println(" " + a));
                    int aulaId = Console.lerInt("ID da aula: ", 1, Integer.MAX_VALUE);
                    LocalDate data = Console.lerData("Data da presença");
                    alunoService.registrarPresenca(aluno.getId(), aulaId, data);
                    Console.sucesso("Presença registrada. Presenças nos últimos 30 dias: "
                            + aluno.presencasNosUltimos30Dias(LocalDate.now()));
                });
                case 6 -> consultar(() -> {
                    LocalDate hoje = LocalDate.now();
                    List<Aluno> lista = alunoService.alunosComBaixaFrequencia(hoje);
                    if (lista.isEmpty()) {
                        Console.sucesso("Nenhum aluno com baixa frequência.");
                    }
                    for (Aluno a : lista) {
                        Console.alerta(String.format("%-20s %2d presença(s) nos últimos 30 dias (mínimo %d) tel: %s",
                                a.getNome(), a.presencasNosUltimos30Dias(hoje), Aluno.MINIMO_PRESENCAS_30_DIAS, a.getTelefone()));
                    }
                });
                case 7 -> {
                    for (Plano p : Plano.todos()) {
                        System.out.println(" - " + p + (p.isVip() ? " + aulas VIP e reserva de equipamentos" : ""));
                    }
                }
                default -> { }
            }
        } while (opcao != 0);
    }

    // =====================================================================
    // 3. EQUIPAMENTOS E RESERVAS
    // =====================================================================

    private void menuEquipamentos() {
        int opcao;
        do {
            Console.titulo("3. EQUIPAMENTOS E RESERVAS");
            System.out.println(" 1. Cadastrar equipamento");
            System.out.println(" 2. Listar equipamentos");
            System.out.println(" 3. Alterar status (uso / manutenção)");
            System.out.println(" 4. Reservar equipamento (somente VIP, até 1h)");
            System.out.println(" 5. Cancelar reserva");
            System.out.println(" 6. Listar reservas");
            System.out.println(" 0. Voltar");
            opcao = Console.lerInt("Opção: ", 0, 6);
            switch (opcao) {
                case 1 -> alterar(() -> Console.sucesso("Cadastrado: "
                        + equipamentoService.cadastrar(Console.lerTexto("Nome do equipamento: "))));
                case 2 -> consultar(this::listarEquipamentos);
                case 3 -> alterar(() -> {
                    Equipamento eq = escolherEquipamento();
                    System.out.println(" 1. Iniciar uso\n 2. Finalizar uso\n 3. Enviar para manutenção\n 4. Concluir manutenção");
                    switch (Console.lerInt("Ação: ", 1, 4)) {
                        case 1 -> equipamentoService.iniciarUso(eq.getId());
                        case 2 -> equipamentoService.finalizarUso(eq.getId());
                        case 3 -> equipamentoService.enviarParaManutencao(eq.getId());
                        default -> equipamentoService.concluirManutencao(eq.getId());
                    }
                    Console.sucesso("Status atualizado: " + eq);
                });
                case 4 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    Equipamento eq = escolherEquipamento();
                    LocalDateTime inicio = Console.lerDataHora("Início da reserva");
                    int minutos = Console.lerInt("Duração em minutos (1 a 60): ", 1, 60);
                    Console.sucesso("Reserva feita: " + equipamentoService.reservar(aluno.getId(), eq.getId(), inicio, minutos));
                });
                case 5 -> alterar(() -> {
                    listarReservas();
                    int id = Console.lerInt("ID da reserva: ", 1, Integer.MAX_VALUE);
                    equipamentoService.cancelarReserva(id);
                    Console.sucesso("Reserva cancelada.");
                });
                case 6 -> consultar(this::listarReservas);
                default -> { }
            }
        } while (opcao != 0);
    }

    // =====================================================================
    // 4. HISTÓRICO E AVALIAÇÕES
    // =====================================================================

    private void menuHistorico() {
        int opcao;
        do {
            Console.titulo("4. HISTÓRICO E AVALIAÇÕES FÍSICAS");
            System.out.println(" 1. Registrar treino livre");
            System.out.println(" 2. Registrar avaliação física");
            System.out.println(" 3. Ver histórico completo do aluno");
            System.out.println(" 4. Relatório de evolução (tela + arquivo)");
            System.out.println(" 0. Voltar");
            opcao = Console.lerInt("Opção: ", 0, 4);
            switch (opcao) {
                case 1 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    LocalDate data = Console.lerData("Data do treino");
                    String descricao = Console.lerTexto("Descrição (exercícios, cargas...): ");
                    historicoService.registrarTreino(aluno.getId(), data, descricao);
                    Console.sucesso("Treino registrado no histórico de " + aluno.getNome() + ".");
                });
                case 2 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    LocalDate data = Console.lerData("Data da avaliação");
                    double peso = Console.lerDouble("Peso (kg): ", 1, 400);
                    double gordura = Console.lerDouble("% de gordura: ", 1, 74);
                    AvaliacaoFisica av = historicoService.registrarAvaliacao(aluno.getId(), data, peso, gordura);
                    Console.sucesso("Avaliação registrada. Massa magra: " + Formatos.numero(av.getMassaMagra()) + " kg");
                });
                case 3 -> consultar(() -> {
                    Aluno aluno = escolherAluno();
                    if (aluno.getHistorico().isEmpty()) {
                        System.out.println(" Nenhum registro.");
                    }
                    for (RegistroTreino r : aluno.getHistorico()) {
                        System.out.println(" " + Formatos.data(r.getData()) + " " + r.getDescricao());
                    }
                });
                case 4 -> consultar(() -> {
                    Aluno aluno = escolherAluno();
                    String relatorio = historicoService.relatorioEvolucao(aluno.getId(), LocalDate.now());
                    System.out.println();
                    System.out.println(relatorio);
                    Path arquivo = persistencia.salvarRelatorio("evolucao_aluno_" + aluno.getId() + ".txt", relatorio);
                    if (arquivo != null) {
                        Console.sucesso("Relatório salvo em " + arquivo);
                    }
                });
                default -> { }
            }
        } while (opcao != 0);
    }

    // =====================================================================
    // 5. PAGAMENTOS E RELATÓRIOS
    // =====================================================================

    private void menuFinanceiro() {
        int opcao;
        do {
            Console.titulo("5. PAGAMENTOS E RELATÓRIOS FINANCEIROS");
            System.out.println(" 1. Registrar pagamento de mensalidade");
            System.out.println(" 2. Simular valor com multa");
            System.out.println(" 3. Mensalidades pendentes do mês");
            System.out.println(" 4. Listar pagamentos");
            System.out.println(" 5. Relatório de receita (tela + arquivo)");
            System.out.println(" 0. Voltar");
            opcao = Console.lerInt("Opção: ", 0, 5);
            switch (opcao) {
                case 1 -> alterar(() -> {
                    Aluno aluno = escolherAluno();
                    YearMonth ref = Console.lerMes("Mês de referência");
                    LocalDate data = Console.lerData("Data do pagamento");
                    Pagamento p = financeiroService.registrarPagamento(aluno.getId(), ref, data);
                    Console.sucesso("Pagamento registrado: " + p);
                    if (p.getMulta() > 0) {
                        Console.alerta(p.getDiasAtraso() + " dia(s) de atraso: multa de " + Formatos.moeda(p.getMulta())
                                + " (2% + 0,1% por dia).");
                    }
                });
                case 2 -> consultar(() -> {
                    Aluno aluno = escolherAluno();
                    YearMonth ref = Console.lerMes("Mês de referência");
                    LocalDate data = Console.lerData("Pagar em");
                    System.out.println(" Vencimento: " + Formatos.data(financeiroService.vencimentoDe(aluno, ref)));
                    System.out.println(" Valor a pagar: " + Formatos.moeda(financeiroService.valorAtualizado(aluno, ref, data)));
                });
                case 3 -> consultar(() -> {
                    YearMonth ref = Console.lerMes("Mês de referência");
                    List<Aluno> pendentes = financeiroService.pendentes(ref);
                    if (pendentes.isEmpty()) {
                        Console.sucesso("Nenhuma mensalidade pendente em " + Formatos.mes(ref) + ".");
                    }
                    LocalDate hoje = LocalDate.now();
                    for (Aluno a : pendentes) {
                        LocalDate venc = financeiroService.vencimentoDe(a, ref);
                        String situacao = venc.isBefore(hoje) ? "VENCIDA" : "a vencer";
                        System.out.printf(" %-20s venc %s %-8s valor hoje: %s%n", a.getNome(), Formatos.data(venc),
                                situacao, Formatos.moeda(financeiroService.valorAtualizado(a, ref, hoje)));
                    }
                });
                case 4 -> consultar(() -> {
                    List<Pagamento> lista = financeiroService.pagamentosOrdenados();
                    if (lista.isEmpty()) {
                        System.out.println(" Nenhum pagamento registrado.");
                    }
                    lista.forEach(p -> System.out.println(" " + p));
                });
                case 5 -> consultar(() -> {
                    YearMonth inicio = Console.lerMes("Mês inicial");
                    YearMonth fim = Console.lerMes("Mês final");
                    String relatorio = financeiroService.relatorioReceita(inicio, fim);
                    System.out.println();
                    System.out.println(relatorio);
                    Path arquivo = persistencia.salvarRelatorio("receita_" + inicio + "_a_" + fim + ".txt", relatorio);
                    if (arquivo != null) {
                        Console.sucesso("Relatório salvo em " + arquivo);
                    }
                });
                default -> { }
            }
        } while (opcao != 0);
    }

    // =====================================================================
    // Listagens e seleção
    // =====================================================================

    private void listarProfessores() {
        if (academia.getProfessores().isEmpty()) {
            System.out.println(" Nenhum professor cadastrado.");
        }
        academia.getProfessores().forEach(p -> System.out.println("    " + p + "   tel: " + p.getTelefone()));
    }

    private void listarAlunos() {
        if (academia.getAlunos().isEmpty()) {
            System.out.println(" Nenhum aluno cadastrado.");
        }
        LocalDate hoje = LocalDate.now();
        for (Aluno a : academia.getAlunos()) {
            System.out.printf(" #%-3d %-20s %-7s venc. dia %-2d modalidades: %-28s presenças 30d: %d%n",
                    a.getId(), a.getNome(), a.getPlano().getNome(), a.getDiaVencimento(),
                    academia.modalidadesDoAluno(a), a.presencasNosUltimos30Dias(hoje));
        }
    }

    private void listarGrade() {
        List<Aula> grade = aulaService.gradeOrdenada();
        if (grade.isEmpty()) {
            System.out.println(" Nenhuma aula cadastrada.");
        }
        grade.forEach(a -> System.out.println(" " + a));
    }

    private void listarEquipamentos() {
        if (academia.getEquipamentos().isEmpty()) {
            System.out.println(" Nenhum equipamento cadastrado.");
        }
        academia.getEquipamentos().forEach(e -> System.out.println("    " + e));
    }

    private void listarReservas() {
        List<Reserva> reservas = equipamentoService.reservasOrdenadas();
        if (reservas.isEmpty()) {
            System.out.println(" Nenhuma reserva.");
        }
        reservas.forEach(r -> System.out.println(" " + r));
    }

    private Aluno escolherAluno() {
        if (academia.getAlunos().isEmpty()) {
            throw new AcademiaException("Nenhum aluno cadastrado.");
        }
        academia.getAlunos().forEach(a -> System.out.println(" " + a));
        return academia.buscarAluno(Console.lerInt("ID do aluno: ", 1, Integer.MAX_VALUE));
    }

    private Professor escolherProfessor() {
        if (academia.getProfessores().isEmpty()) {
            throw new AcademiaException("Cadastre um professor primeiro.");
        }
        listarProfessores();
        return academia.buscarProfessor(Console.lerInt("ID do professor: ", 1, Integer.MAX_VALUE));
    }

    private Aula escolherAula() {
        if (academia.getAulas().isEmpty()) {
            throw new AcademiaException("Nenhuma aula cadastrada.");
        }
        listarGrade();
        return academia.buscarAula(Console.lerInt("ID da aula: ", 1, Integer.MAX_VALUE));
    }

    private Equipamento escolherEquipamento() {
        if (academia.getEquipamentos().isEmpty()) {
            throw new AcademiaException("Nenhum equipamento cadastrado.");
        }
        listarEquipamentos();
        return academia.buscarEquipamento(Console.lerInt("ID do equipamento: ", 1, Integer.MAX_VALUE));
    }

    private Plano escolherPlano() {
        Plano[] planos = Plano.todos();
        for (int i = 0; i < planos.length; i++) {
            System.out.printf(" %d. %s%n", i + 1, planos[i]);
        }
        return planos[Console.lerInt("Plano: ", 1, planos.length) - 1];
    }
}
