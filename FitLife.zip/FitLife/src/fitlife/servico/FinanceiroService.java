package fitlife.servico;

import fitlife.excecao.AcademiaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Pagamento;
import fitlife.modelo.Plano;
import fitlife.modelo.TipoModalidade;
import fitlife.util.Formatos;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/** Requisito 5: pagamentos de mensalidade (com multa) e relatórios de receita. */
public class FinanceiroService {

    private static final String SEM_MODALIDADE = "Sem modalidade";
    private final Academia academia;

    public FinanceiroService(Academia academia) {
        this.academia = academia;
    }

    public LocalDate vencimentoDe(Aluno aluno, YearMonth referencia) {
        return referencia.atDay(Math.min(aluno.getDiaVencimento(), referencia.lengthOfMonth()));
    }

    public Pagamento registrarPagamento(int alunoId, YearMonth referencia, LocalDate dataPagamento) {
        Aluno aluno = academia.buscarAluno(alunoId);
        if (dataPagamento.isAfter(LocalDate.now())) {
            throw new AcademiaException("A data do pagamento não pode estar no futuro.");
        }
        boolean jaPago = academia.getPagamentos().stream()
                .anyMatch(p -> p.getAlunoId() == alunoId && p.getReferencia().equals(referencia));
        if (jaPago) {
            throw new AcademiaException("A mensalidade de " + Formatos.mes(referencia) + " de "
                    + aluno.getNome() + " já foi paga.");
        }
        Plano plano = aluno.getPlano();
        Pagamento pagamento = new Pagamento(academia.gerarId(Academia.PAGAMENTO), aluno.getId(), aluno.getNome(),
                plano, referencia, vencimentoDe(aluno, referencia), dataPagamento, plano.getValorMensal());
        academia.adicionarPagamento(pagamento);
        return pagamento;
    }

    /** Quanto o aluno pagaria se quitasse a mensalidade na data informada. */
    public double valorAtualizado(Aluno aluno, YearMonth referencia, LocalDate data) {
        double valor = aluno.getPlano().getValorMensal();
        long dias = Pagamento.diasEntre(vencimentoDe(aluno, referencia), data);
        return valor + Pagamento.calcularMulta(valor, dias);
    }

    /** Alunos matriculados que ainda não pagaram a referência informada. */
    public List<Aluno> pendentes(YearMonth referencia) {
        return academia.getAlunos().stream()
                .filter(a -> !a.getDataMatricula().isAfter(referencia.atEndOfMonth()))
                .filter(a -> academia.getPagamentos().stream()
                        .noneMatch(p -> p.getAlunoId() == a.getId() && p.getReferencia().equals(referencia)))
                .collect(Collectors.toList());
    }

    public List<Pagamento> pagamentosOrdenados() {
        return academia.getPagamentos().stream()
                .sorted(Comparator.comparing(Pagamento::getReferencia).thenComparing(Pagamento::getDataPagamento))
                .collect(Collectors.toList());
    }

    /**
    * Relatório de receita do período (por mês de referência), detalhado por plano e por modalidade.
    * Por modalidade, o valor de cada pagamento é dividido igualmente entre as modalidades
    * que o aluno faz (rateio), para a soma bater com o total.
    */
    public String relatorioReceita(YearMonth inicio, YearMonth fim) {
        if (fim.isBefore(inicio)) {
            throw new AcademiaException("O mês final não pode ser anterior ao inicial.");
        }
        List<Pagamento> doPeriodo = academia.getPagamentos().stream()
                .filter(p -> !p.getReferencia().isBefore(inicio) && !p.getReferencia().isAfter(fim))
                .collect(Collectors.toList());

        Map<String, double[]> porPlano = new LinkedHashMap<>(); // [qtd, base, multa]
        for (Plano plano : Plano.todos()) {
            porPlano.put(plano.getNome(), new double[3]);
        }
        Map<String, Double> porModalidade = new LinkedHashMap<>();
        for (TipoModalidade m : TipoModalidade.values()) {
            porModalidade.put(m.toString(), 0.0);
        }
        porModalidade.put(SEM_MODALIDADE, 0.0);

        double totalBase = 0;
        double totalMulta = 0;
        for (Pagamento p : doPeriodo) {
            double[] linha = porPlano.computeIfAbsent(p.getPlano().getNome(), k -> new double[3]);
            linha[0]++;
            linha[1] += p.getValorBase();
            linha[2] += p.getMulta();
            totalBase += p.getValorBase();
            totalMulta += p.getMulta();

            List<String> modalidades = modalidadesDoAlunoPorId(p.getAlunoId());
            double parte = p.getTotal() / modalidades.size();
            for (String m : modalidades) {
                porModalidade.merge(m, parte, Double::sum);
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("RELATÓRIO DE RECEITA - FITLIFE\n");
        sb.append("Período (referência): ").append(Formatos.mes(inicio)).append(" a ").append(Formatos.mes(fim)).append("\n");
        sb.append("Pagamentos no período: ").append(doPeriodo.size()).append("\n\n");

        sb.append("POR PLANO\n");
        sb.append(String.format(" %-8s %5s %14s %12s %14s%n", "Plano", "Qtd", "Mensalidades", "Multas", "Total"));
        for (Map.Entry<String, double[]> e : porPlano.entrySet()) {
            double[] v = e.getValue();
            sb.append(String.format(" %-8s %5d %14s %12s %14s%n", e.getKey(), (int) v[0],
                    Formatos.moeda(v[1]), Formatos.moeda(v[2]), Formatos.moeda(v[1] + v[2])));
        }

        sb.append("\nPOR MODALIDADE (rateio do valor pago entre as modalidades do aluno)\n");
        for (Map.Entry<String, Double> e : porModalidade.entrySet()) {
            if (e.getKey().equals(SEM_MODALIDADE) && e.getValue() == 0) {
                continue;
            }
            sb.append(String.format(" %-16s %14s%n", e.getKey(), Formatos.moeda(e.getValue())));
        }

        sb.append("\nTOTAIS\n");
        sb.append(" Mensalidades: ").append(Formatos.moeda(totalBase)).append("\n");
        sb.append(" Multas:      ").append(Formatos.moeda(totalMulta)).append("\n");
        sb.append(" RECEITA TOTAL: ").append(Formatos.moeda(totalBase + totalMulta)).append("\n");
        return sb.toString();
    }

    private List<String> modalidadesDoAlunoPorId(int alunoId) {
        List<String> nomes = new ArrayList<>();
        academia.getAlunos().stream().filter(a -> a.getId() == alunoId).findFirst().ifPresent(aluno -> {
            Set<TipoModalidade> mods = academia.modalidadesDoAluno(aluno);
            mods.forEach(m -> nomes.add(m.toString()));
        });
        if (nomes.isEmpty()) {
            nomes.add(SEM_MODALIDADE);
        }
        return nomes;
    }
}
