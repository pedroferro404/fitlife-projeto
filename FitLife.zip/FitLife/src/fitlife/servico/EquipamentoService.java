package fitlife.servico;

import fitlife.excecao.AcademiaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Equipamento;
import fitlife.modelo.Reserva;
import fitlife.modelo.StatusEquipamento;
import fitlife.util.Formatos;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/** Requisito 3: controle de equipamentos e reservas (só VIP, até 1h, sem conflito). */
public class EquipamentoService {

    private final Academia academia;

    public EquipamentoService(Academia academia) {
        this.academia = academia;
    }

    public Equipamento cadastrar(String nome) {
        Equipamento equipamento = new Equipamento(academia.gerarId(Academia.EQUIPAMENTO), nome,
                StatusEquipamento.DISPONIVEL);
        academia.adicionarEquipamento(equipamento);
        return equipamento;
    }

    public void iniciarUso(int equipamentoId) {
        academia.buscarEquipamento(equipamentoId).iniciarUso();
    }

    public void finalizarUso(int equipamentoId) {
        academia.buscarEquipamento(equipamentoId).finalizarUso();
    }

    public void enviarParaManutencao(int equipamentoId) {
        academia.buscarEquipamento(equipamentoId).enviarParaManutencao();
    }

    public void concluirManutencao(int equipamentoId) {
        academia.buscarEquipamento(equipamentoId).concluirManutencao();
    }

    public Reserva reservar(int alunoId, int equipamentoId, LocalDateTime inicio, int duracaoMinutos) {
        Aluno aluno = academia.buscarAluno(alunoId);
        Equipamento equipamento = academia.buscarEquipamento(equipamentoId);

        if (!aluno.isVip()) {
            throw new AcademiaException("Reserva de equipamentos é exclusiva do plano VIP ("
                    + aluno.getNome() + " é plano " + aluno.getPlano().getNome() + ").");
        }
        if (duracaoMinutos < 1 || duracaoMinutos > Reserva.DURACAO_MAXIMA_MINUTOS) {
            throw new AcademiaException("A reserva deve durar entre 1 e " + Reserva.DURACAO_MAXIMA_MINUTOS + " minutos.");
        }
        if (inicio.isBefore(LocalDateTime.now().minusMinutes(1))) {
            throw new AcademiaException("Não é possível reservar em um horário que já passou.");
        }
        if (equipamento.isEmManutencao()) {
            throw new AcademiaException(equipamento.getNome() + " está em manutenção.");
        }
        LocalDateTime fim = inicio.plusMinutes(duracaoMinutos);

        for (Reserva existente : academia.getReservas()) {
            if (!existente.conflitaCom(inicio, fim)) {
                continue;
            }
            if (existente.getEquipamento().equals(equipamento)) {
                throw new AcademiaException("Conflito: " + equipamento.getNome() + " já está reservado(a) de "
                        + Formatos.dataHora(existente.getInicio()) + " até "
                        + Formatos.hora(existente.getFim().toLocalTime()) + ".");
            }
            if (existente.getAluno().equals(aluno)) {
                throw new AcademiaException(aluno.getNome() + " já tem outra reserva nesse horário ("
                        + existente.getEquipamento().getNome() + ").");
            }
        }

        Reserva reserva = new Reserva(academia.gerarId(Academia.RESERVA), equipamento, aluno, inicio, fim);
        academia.adicionarReserva(reserva);
        return reserva;
    }

    public void cancelarReserva(int reservaId) {
        academia.removerReserva(academia.buscarReserva(reservaId));
    }

    public List<Reserva> reservasOrdenadas() {
        return academia.getReservas().stream()
                .sorted(Comparator.comparing(Reserva::getInicio))
                .collect(Collectors.toList());
    }
}
