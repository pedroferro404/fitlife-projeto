package fitlife.servico;

import fitlife.excecao.AcademiaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.AvaliacaoFisica;
import fitlife.modelo.RegistroTreino;
import fitlife.util.Formatos;

import java.time.LocalDate;
import java.util.List;

/** Requisito 4: histórico de treinos, avaliações físicas e relatório de evolução. */
public class HistoricoService {

    private static final int ULTIMOS_REGISTROS = 10;
    private final Academia academia;

    public HistoricoService(Academia academia) {
        this.academia = academia;
    }

    public void registrarTreino(int alunoId, LocalDate data, String descricao) {
        if (data.isAfter(LocalDate.now())) {
            throw new AcademiaException("Não é possível registrar treino em data futura.");
        }
        academia.buscarAluno(alunoId).adicionarRegistro(new RegistroTreino(data, descricao));
    }

    public AvaliacaoFisica registrarAvaliacao(int alunoId, LocalDate data, double peso, double percentualGordura) {
        if (data.isAfter(LocalDate.now())) {
            throw new AcademiaException("Não é possível registrar avaliação em data futura.");
        }
        AvaliacaoFisica avaliacao = new AvaliacaoFisica(data, peso, percentualGordura);
        academia.buscarAluno(alunoId).adicionarAvaliacao(avaliacao);
        return avaliacao;
    }

    /** Monta o texto do relatório de evolução (usado na tela e no arquivo .txt). */
    public String relatorioEvolucao(int alunoId, LocalDate hoje) {
        Aluno aluno = academia.buscarAluno(alunoId);
        StringBuilder sb = new StringBuilder();
        sb.append("RELATÓRIO DE EVOLUÇÃO - FITLIFE\n");
        sb.append("Gerado em ").append(Formatos.data(hoje)).append("\n\n");
        sb.append("Aluno: ").append(aluno.getNome()).append(" (#").append(aluno.getId()).append(")\n");
        sb.append("Plano: ").append(aluno.getPlano()).append("\n");
        sb.append("Matrícula: ").append(Formatos.data(aluno.getDataMatricula())).append("\n");
        sb.append("Modalidades: ").append(academia.modalidadesDoAluno(aluno)).append("\n");
        long presencas = aluno.presencasNosUltimos30Dias(hoje);
        sb.append("Presenças nos últimos 30 dias: ").append(presencas);
        if (aluno.temBaixaFrequencia(hoje)) {
            sb.append(" [ALERTA: baixa frequência, mínimo ").append(Aluno.MINIMO_PRESENCAS_30_DIAS).append("]");
        }
        sb.append("\n\n");

        List<AvaliacaoFisica> avaliacoes = aluno.getAvaliacoes();
        sb.append("AVALIAÇÕES FÍSICAS\n");
        if (avaliacoes.isEmpty()) {
            sb.append(" Nenhuma avaliação registrada.\n");
        } else {
            sb.append(String.format(" %-12s %10s %10s %14s%n", "Data", "Peso (kg)", "% Gordura", "Massa magra"));
            AvaliacaoFisica anterior = null;
            for (AvaliacaoFisica a : avaliacoes) {
                sb.append(String.format(" %-12s %10s %10s %14s", Formatos.data(a.getData()),
                        Formatos.numero(a.getPeso()), Formatos.numero(a.getPercentualGordura()),
                        Formatos.numero(a.getMassaMagra())));
                if (anterior != null) {
                    sb.append(String.format(" (peso %s, gordura %s)",
                            variacao(a.getPeso() - anterior.getPeso(), " kg"),
                            variacao(a.getPercentualGordura() - anterior.getPercentualGordura(), " p.p.")));
                }
                sb.append("\n");
                anterior = a;
            }
            if (avaliacoes.size() > 1) {
                AvaliacaoFisica primeira = avaliacoes.get(0);
                AvaliacaoFisica ultima = avaliacoes.get(avaliacoes.size() - 1);
                sb.append("\n Evolução total desde ").append(Formatos.data(primeira.getData())).append(":\n");
                sb.append("    Peso: ").append(variacao(ultima.getPeso() - primeira.getPeso(), " kg")).append("\n");
                sb.append("    Gordura: ").append(variacao(
                        ultima.getPercentualGordura() - primeira.getPercentualGordura(), " p.p.")).append("\n");
                sb.append("    Massa magra: ").append(variacao(
                        ultima.getMassaMagra() - primeira.getMassaMagra(), " kg")).append("\n");
            }
        }

        List<RegistroTreino> historico = aluno.getHistorico();
        sb.append("\nÚLTIMOS REGISTROS DO HISTÓRICO (").append(historico.size()).append(" no total)\n");
        if (historico.isEmpty()) {
            sb.append(" Nenhum treino ou aula registrado.\n");
        }
        int inicio = Math.max(0, historico.size() - ULTIMOS_REGISTROS);
        for (RegistroTreino r : historico.subList(inicio, historico.size())) {
            sb.append(" ").append(Formatos.data(r.getData())).append(" ").append(r.getDescricao()).append("\n");
        }
        return sb.toString();
    }

    private static String variacao(double valor, String unidade) {
        String sinal = valor > 0 ? "+" : "";
        return sinal + Formatos.numero(valor) + unidade;
    }
}
