package fitlife.servico;

import fitlife.excecao.AcademiaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.AulaVip;
import fitlife.modelo.Plano;
import fitlife.modelo.Presenca;
import fitlife.modelo.RegistroTreino;
import fitlife.modelo.Reserva;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/** Requisito 2: alunos, planos e controle de frequência. */
public class AlunoService {

    private final Academia academia;

    public AlunoService(Academia academia) {
        this.academia = academia;
    }

    public Aluno cadastrarAluno(String nome, String telefone, Plano plano, int diaVencimento) {
        return cadastrarAluno(nome, telefone, plano, diaVencimento, LocalDate.now());
    }

    /** Sobrecarga usada quando a matrícula é de uma data anterior (ex.: dados de exemplo). */
    public Aluno cadastrarAluno(String nome, String telefone, Plano plano, int diaVencimento, LocalDate dataMatricula) {
        Aluno aluno = new Aluno(academia.gerarId(Academia.ALUNO), nome, telefone, plano,
                diaVencimento, dataMatricula);
        academia.adicionarAluno(aluno);
        return aluno;
    }

    /** Troca de plano, impedindo um downgrade que deixaria o aluno fora das regras. */
    public void trocarPlano(int alunoId, Plano novoPlano) {
        Aluno aluno = academia.buscarAluno(alunoId);
        int modalidades = academia.modalidadesDoAluno(aluno).size();
        if (!novoPlano.permiteQuantidadeModalidades(modalidades)) {
            throw new AcademiaException(aluno.getNome() + " está em " + modalidades
                    + " modalidades; o plano " + novoPlano.getNome() + " permite "
                    + novoPlano.getDescricaoLimite() + ". Cancele inscrições antes.");
        }
        if (!novoPlano.isVip()) {
            boolean temAulaVip = academia.aulasDoAluno(aluno).stream().anyMatch(a -> a instanceof AulaVip);
            if (temAulaVip) {
                throw new AcademiaException("Cancele as aulas especiais VIP do aluno antes de sair do VIP.");
            }
            boolean temReservaFutura = academia.getReservas().stream()
                    .anyMatch(r -> r.getAluno().equals(aluno) && r.getFim().isAfter(LocalDateTime.now()));
            if (temReservaFutura) {
                throw new AcademiaException("Cancele as reservas de equipamento do aluno antes de sair do VIP.");
            }
        }
        aluno.setPlano(novoPlano);
    }

    public void removerAluno(int alunoId) {
        academia.removerAluno(academia.buscarAluno(alunoId));
    }

    /** Só registra presença de quem está de fato inscrito (não vale lista de espera). */
    public void registrarPresenca(int alunoId, int aulaId, LocalDate data) {
        Aluno aluno = academia.buscarAluno(alunoId);
        Aula aula = academia.buscarAula(aulaId);
        if (data.isAfter(LocalDate.now())) {
            throw new AcademiaException("Não é possível registrar presença em data futura.");
        }
        if (!aula.isInscrito(aluno)) {
            throw new AcademiaException(aluno.getNome() + " não está inscrito(a) na aula #" + aulaId + ".");
        }
        aluno.registrarPresenca(new Presenca(data, aulaId));
        aluno.adicionarRegistro(new RegistroTreino(data,
                "Aula de " + aula.getModalidade() + " (" + aula.getTipo() + ") com " + aula.getProfessor().getNome()));
    }

    /** Alunos com menos de 8 presenças nos últimos 30 dias, do menor para o maior. */
    public List<Aluno> alunosComBaixaFrequencia(LocalDate hoje) {
        return academia.getAlunos().stream()
                .filter(a -> a.temBaixaFrequencia(hoje))
                .sorted(Comparator.comparingLong(a -> a.presencasNosUltimos30Dias(hoje)))
                .collect(Collectors.toList());
    }

    public List<Reserva> reservasDoAluno(Aluno aluno) {
        return academia.getReservas().stream().filter(r -> r.getAluno().equals(aluno)).collect(Collectors.toList());
    }
}
