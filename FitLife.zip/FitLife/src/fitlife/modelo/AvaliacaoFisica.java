package fitlife.modelo;

import java.time.LocalDate;
import java.util.Objects;

/** Avaliação física periódica: peso e percentual de gordura. */
public class AvaliacaoFisica {

    private final LocalDate data;
    private final double peso;
    private final double percentualGordura;

    public AvaliacaoFisica(LocalDate data, double peso, double percentualGordura) {
        if (peso <= 0 || peso > 400) {
            throw new IllegalArgumentException("Peso inválido: informe um valor entre 1 e 400 kg.");
        }
        if (percentualGordura <= 0 || percentualGordura >= 75) {
            throw new IllegalArgumentException("Percentual de gordura inválido: informe entre 1 e 74%.");
        }
        this.data = Objects.requireNonNull(data);
        this.peso = peso;
        this.percentualGordura = percentualGordura;
    }

    public LocalDate getData() {
        return data;
    }

    public double getPeso() {
        return peso;
    }

    public double getPercentualGordura() {
        return percentualGordura;
    }

    public double getMassaGorda() {
        return peso * percentualGordura / 100.0;
    }

    public double getMassaMagra() {
        return peso - getMassaGorda();
    }
}
