package fitlife.modelo;

import java.util.Objects;

/** HERANÇA: Professor é uma Pessoa com uma especialidade. */
public class Professor extends Pessoa {

    private TipoModalidade especialidade;

    public Professor(int id, String nome, String telefone, TipoModalidade especialidade) {
        super(id, nome, telefone);
        setEspecialidade(especialidade);
    }

    public TipoModalidade getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(TipoModalidade especialidade) {
        this.especialidade = Objects.requireNonNull(especialidade, "Especialidade obrigatória.");
    }

    @Override
    public String getPapel() {
        return "Professor(a) de " + especialidade;
    }
}
