package fitlife.modelo;

import java.time.LocalDate;
import java.util.Objects;

/** Item do histórico do aluno (aula frequentada ou treino livre). */
public class RegistroTreino {

    private final LocalDate data;
    private final String descricao;

    public RegistroTreino(LocalDate data, String descricao) {
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição do treino não pode ficar vazia.");
        }
        this.data = Objects.requireNonNull(data);
        this.descricao = descricao.trim();
    }

    public LocalDate getData() {
        return data;
    }

    public String getDescricao() {
        return descricao;
    }
}
