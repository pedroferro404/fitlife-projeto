package fitlife.modelo;

/** Resultado de uma tentativa de inscrição em aula. */
public enum SituacaoInscricao {
    INSCRITO,
    LISTA_ESPERA
}
