package fitlife.modelo;

/** Plano mensal: R$ 120,00/mês, até 2 modalidades. */
public class PlanoMensal extends Plano {

    @Override
    public String getCodigo() {
        return "MENSAL";
    }

    @Override
    public String getNome() {
        return "Mensal";
    }

    @Override
    public double getValorMensal() {
        return 120.00;
    }

    @Override
    public int getLimiteModalidades() {
        return 2;
    }
}
