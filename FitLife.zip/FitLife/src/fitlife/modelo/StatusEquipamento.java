package fitlife.modelo;

/** Situação atual de um equipamento. */
public enum StatusEquipamento {
    DISPONIVEL("Disponível"),
    EM_USO("Em uso"),
    EM_MANUTENCAO("Em manutenção");

    private final String descricao;

    StatusEquipamento(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
