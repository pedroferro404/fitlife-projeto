package fitlife.modelo;

/** Modalidades oferecidas pela academia. */
public enum TipoModalidade {
    YOGA("Yoga"),
    MUSCULACAO("Musculação"),
    PILATES("Pilates");

    private final String descricao;

    TipoModalidade(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
