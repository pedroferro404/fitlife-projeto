package fitlife.modelo;

import java.time.DayOfWeek;
import java.time.LocalTime;

/**
* HERANÇA + POLIMORFISMO: aula especial exclusiva para alunos VIP.
* Só muda a regra de quem pode entrar; todo o resto é herdado de Aula.
*/
public class AulaVip extends Aula {

    public AulaVip(int id, TipoModalidade modalidade, Professor professor,
                DayOfWeek diaSemana, LocalTime horario, int limiteVagas) {
        super(id, modalidade, professor, diaSemana, horario, limiteVagas);
    }

    @Override
    public boolean aceitaAluno(Aluno aluno) {
        return aluno.isVip();
    }

    @Override
    public String getTipo() {
        return "Especial VIP";
    }
}
