package fitlife.modelo;

/** Plano anual: R$ 100,00/mês, até 2 modalidades. */
public class PlanoAnual extends Plano {

    @Override
    public String getCodigo() {
        return "ANUAL";
    }

    @Override
    public String getNome() {
        return "Anual";
    }

    @Override
    public double getValorMensal() {
        return 100.00;
    }

    @Override
    public int getLimiteModalidades() {
        return 2;
    }
}
