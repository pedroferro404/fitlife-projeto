package fitlife.modelo;

import fitlife.util.Formatos;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

/**
* Pagamento de mensalidade. A multa por atraso é 2% fixo + 0,1% por dia.
* Guarda id e nome do aluno (e o plano da época) para que o histórico
* financeiro continue correto mesmo se o aluno trocar de plano ou sair.
*/
public class Pagamento {

    public static final double MULTA_FIXA = 0.02;
    public static final double JUROS_POR_DIA = 0.001;

    private final int id;
    private final int alunoId;
    private final String alunoNome;
    private final Plano plano;
    private final YearMonth referencia;
    private final LocalDate vencimento;
    private final LocalDate dataPagamento;
    private final double valorBase;
    private final double multa;

    public Pagamento(int id, int alunoId, String alunoNome, Plano plano, YearMonth referencia,
                    LocalDate vencimento, LocalDate dataPagamento, double valorBase) {
        if (valorBase <= 0) {
            throw new IllegalArgumentException("Valor da mensalidade inválido.");
        }
        this.id = id;
        this.alunoId = alunoId;
        this.alunoNome = Objects.requireNonNull(alunoNome);
        this.plano = Objects.requireNonNull(plano);
        this.referencia = Objects.requireNonNull(referencia);
        this.vencimento = Objects.requireNonNull(vencimento);
        this.dataPagamento = Objects.requireNonNull(dataPagamento);
        this.valorBase = valorBase;
        this.multa = calcularMulta(valorBase, getDiasAtraso());
    }

    /** Regra do enunciado: sem atraso não há multa; com atraso, 2% + 0,1% por dia. */
    public static double calcularMulta(double valor, long diasAtraso) {
        if (diasAtraso <= 0) {
            return 0.0;
        }
        double multa = valor * (MULTA_FIXA + JUROS_POR_DIA * diasAtraso);
        return Math.round(multa * 100.0) / 100.0;
    }

    public static long diasEntre(LocalDate vencimento, LocalDate pagamento) {
        return Math.max(0, ChronoUnit.DAYS.between(vencimento, pagamento));
    }

    public long getDiasAtraso() {
        return diasEntre(vencimento, dataPagamento);
    }

    public double getTotal() {
        return valorBase + multa;
    }

    public int getId() {
        return id;
    }

    public int getAlunoId() {
        return alunoId;
    }

    public String getAlunoNome() {
        return alunoNome;
    }

    public Plano getPlano() {
        return plano;
    }

    public YearMonth getReferencia() {
        return referencia;
    }

    public LocalDate getVencimento() {
        return vencimento;
    }

    public LocalDate getDataPagamento() {
        return dataPagamento;
    }

    public double getValorBase() {
        return valorBase;
    }

    public double getMulta() {
        return multa;
    }

    @Override
    public String toString() {
        return String.format("#%d %-18s %-6s ref %s venc %s pago %s %s + multa %s (%d dias) = %s",
                id, alunoNome, plano.getNome(), Formatos.mes(referencia), Formatos.data(vencimento),
                Formatos.data(dataPagamento), Formatos.moeda(valorBase), Formatos.moeda(multa),
                getDiasAtraso(), Formatos.moeda(getTotal()));
    }
}
