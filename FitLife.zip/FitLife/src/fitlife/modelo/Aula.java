package fitlife.modelo;

import fitlife.excecao.AcademiaException;
import fitlife.util.Formatos;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
* Turma de uma modalidade em um dia/horário fixo, com professor e limite de vagas.
* Quando lota, o aluno vai para a lista de espera — e alunos VIP ficam
* à frente dos não-VIP na fila.
*
* O método inscrever() é um "template": ele chama aceitaAluno(), que as
* subclasses podem sobrescrever (ver AulaVip) — POLIMORFISMO.
*/
public class Aula {

    private final int id;
    private final TipoModalidade modalidade;
    private Professor professor;
    private DayOfWeek diaSemana;
    private LocalTime horario;
    private int limiteVagas;
    private final List<Aluno> inscritos = new ArrayList<>();
    private final List<Aluno> listaEspera = new ArrayList<>();

    public Aula(int id, TipoModalidade modalidade, Professor professor,
                DayOfWeek diaSemana, LocalTime horario, int limiteVagas) {
        this.id = id;
        this.modalidade = Objects.requireNonNull(modalidade);
        this.professor = Objects.requireNonNull(professor);
        this.diaSemana = Objects.requireNonNull(diaSemana);
        this.horario = Objects.requireNonNull(horario);
        if (limiteVagas < 1) {
            throw new IllegalArgumentException("A aula precisa de pelo menos 1 vaga.");
        }
        this.limiteVagas = limiteVagas;
    }

    // ---------- Regras que as subclasses podem mudar ----------

    /** Aula regular aceita qualquer aluno. */
    public boolean aceitaAluno(Aluno aluno) {
        return true;
    }

    public String getTipo() {
        return "Regular";
    }

    // ---------- Inscrição e lista de espera ----------

    public SituacaoInscricao inscrever(Aluno aluno) {
        if (!aceitaAluno(aluno)) {
            throw new AcademiaException("A aula #" + id + " é exclusiva para alunos com plano VIP.");
        }
        if (contem(aluno)) {
            throw new AcademiaException(aluno.getNome() + " já está inscrito(a) ou na lista de espera desta aula.");
        }
        if (!isLotada()) {
            inscritos.add(aluno);
            return SituacaoInscricao.INSCRITO;
        }
        adicionarNaListaEspera(aluno);
        return SituacaoInscricao.LISTA_ESPERA;
    }

    /** VIP entra logo depois do último VIP da fila; os demais vão para o final. */
    private void adicionarNaListaEspera(Aluno aluno) {
        if (aluno.isVip()) {
            int posicao = 0;
            while (posicao < listaEspera.size() && listaEspera.get(posicao).isVip()) {
                posicao++;
            }
            listaEspera.add(posicao, aluno);
        } else {
            listaEspera.add(aluno);
        }
    }

    /**
    * Remove o aluno da aula (ou da lista de espera).
    * Se abriu uma vaga, promove o primeiro da fila e o devolve; senão, devolve null.
    */
    public Aluno remover(Aluno aluno) {
        if (listaEspera.remove(aluno)) {
            return null;
        }
        if (!inscritos.remove(aluno)) {
            throw new AcademiaException(aluno.getNome() + " não está inscrito(a) nesta aula.");
        }
        return promoverDaListaEspera();
    }

    private Aluno promoverDaListaEspera() {
        if (listaEspera.isEmpty() || isLotada()) {
            return null;
        }
        Aluno promovido = listaEspera.remove(0);
        inscritos.add(promovido);
        return promovido;
    }

    public boolean contem(Aluno aluno) {
        return inscritos.contains(aluno) || listaEspera.contains(aluno);
    }

    public boolean isInscrito(Aluno aluno) {
        return inscritos.contains(aluno);
    }

    public boolean isLotada() {
        return inscritos.size() >= limiteVagas;
    }

    public int getVagasLivres() {
        return Math.max(0, limiteVagas - inscritos.size());
    }

    // ---------- Usados só ao carregar do arquivo (já validados antes) ----------

    public void restaurarInscrito(Aluno aluno) {
        inscritos.add(aluno);
    }

    public void restaurarEspera(Aluno aluno) {
        listaEspera.add(aluno);
    }

    // ---------- Getters / setters ----------

    public int getId() {
        return id;
    }

    public TipoModalidade getModalidade() {
        return modalidade;
    }

    public Professor getProfessor() {
        return professor;
    }

    public DayOfWeek getDiaSemana() {
        return diaSemana;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public int getLimiteVagas() {
        return limiteVagas;
    }

    public List<Aluno> getInscritos() {
        return Collections.unmodifiableList(inscritos);
    }

    public List<Aluno> getListaEspera() {
        return Collections.unmodifiableList(listaEspera);
    }

    public void reagendar(DayOfWeek novoDia, LocalTime novoHorario) {
        this.diaSemana = Objects.requireNonNull(novoDia);
        this.horario = Objects.requireNonNull(novoHorario);
    }

    /** Diminuir abaixo do número de inscritos é proibido; aumentar promove quem está na fila. */
    public void setLimiteVagas(int novoLimite) {
        if (novoLimite < 1) {
            throw new IllegalArgumentException("A aula precisa de pelo menos 1 vaga.");
        }
        if (novoLimite < inscritos.size()) {
            throw new AcademiaException("Já existem " + inscritos.size()
                    + " inscritos; o limite não pode ser menor que isso.");
        }
        this.limiteVagas = novoLimite;
        while (promoverDaListaEspera() != null) {
            // promove enquanto houver vaga e fila
        }
    }

    @Override
    public String toString() {
        return String.format("#%d %-11s %-14s %-14s %s prof. %-15s vagas %d/%d espera: %d",
                id, modalidade, "[" + getTipo() + "]", Formatos.diaSemana(diaSemana),
                Formatos.hora(horario), professor.getNome(), inscritos.size(), limiteVagas,
                listaEspera.size());
    }
}
