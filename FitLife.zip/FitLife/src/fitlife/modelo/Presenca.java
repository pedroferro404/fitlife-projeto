package fitlife.modelo;

import java.time.LocalDate;
import java.util.Objects;

/** Registro de presença de um aluno em uma aula em determinada data. */
public class Presenca {

    private final LocalDate data;
    private final int aulaId;

    public Presenca(LocalDate data, int aulaId) {
        this.data = Objects.requireNonNull(data);
        this.aulaId = aulaId;
    }

    public LocalDate getData() {
        return data;
    }

    public int getAulaId() {
        return aulaId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Presenca)) {
            return false;
        }
        Presenca outra = (Presenca) o;
        return aulaId == outra.aulaId && data.equals(outra.data);
    }

    @Override
    public int hashCode() {
        return Objects.hash(data, aulaId);
    }
}
