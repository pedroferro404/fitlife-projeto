package fitlife.modelo;

/** Plano VIP: R$ 200,00/mês, modalidades ilimitadas, aulas especiais e reserva de equipamentos. */
public class PlanoVip extends Plano {

    @Override
    public String getCodigo() {
        return "VIP";
    }

    @Override
    public String getNome() {
        return "VIP";
    }

    @Override
    public double getValorMensal() {
        return 200.00;
    }

    @Override
    public int getLimiteModalidades() {
        return ILIMITADO;
    }

    @Override
    public boolean isVip() {
        return true;
    }
}
