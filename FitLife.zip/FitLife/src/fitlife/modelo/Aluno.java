package fitlife.modelo;

import fitlife.excecao.AcademiaException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
* HERANÇA: Aluno é uma Pessoa com plano, frequência, avaliações e histórico.
* ENCAPSULAMENTO: as listas internas só são alteradas pelos métodos da classe;
* os getters devolvem cópias somente-leitura.
*/
public class Aluno extends Pessoa {

    public static final int MINIMO_PRESENCAS_30_DIAS = 8;

    private Plano plano;
    private int diaVencimento;
    private final LocalDate dataMatricula;
    private final List<Presenca> presencas = new ArrayList<>();
    private final List<AvaliacaoFisica> avaliacoes = new ArrayList<>();
    private final List<RegistroTreino> historico = new ArrayList<>();

    public Aluno(int id, String nome, String telefone, Plano plano, int diaVencimento, LocalDate dataMatricula) {
        super(id, nome, telefone);
        setPlano(plano);
        setDiaVencimento(diaVencimento);
        this.dataMatricula = Objects.requireNonNull(dataMatricula);
    }

    @Override
    public String getPapel() {
        return "Aluno(a) plano " + plano.getNome();
    }

    public Plano getPlano() {
        return plano;
    }

    public void setPlano(Plano plano) {
        this.plano = Objects.requireNonNull(plano, "Plano obrigatório.");
    }

    public boolean isVip() {
        return plano.isVip();
    }

    public int getDiaVencimento() {
        return diaVencimento;
    }

    public void setDiaVencimento(int dia) {
        if (dia < 1 || dia > 28) {
            throw new IllegalArgumentException("O dia de vencimento deve ser entre 1 e 28.");
        }
        this.diaVencimento = dia;
    }

    public LocalDate getDataMatricula() {
        return dataMatricula;
    }

    // ---------- Frequência ----------

    public void registrarPresenca(Presenca presenca) {
        if (presencas.contains(presenca)) {
            throw new AcademiaException("Presença já registrada para esta aula nesta data.");
        }
        presencas.add(presenca);
    }

    public List<Presenca> getPresencas() {
        return Collections.unmodifiableList(presencas);
    }

    /** Conta as presenças na janela [hoje - 29 dias, hoje] = últimos 30 dias. */
    public long presencasNosUltimos30Dias(LocalDate hoje) {
        LocalDate inicio = hoje.minusDays(29);
        return presencas.stream()
                .filter(p -> !p.getData().isBefore(inicio) && !p.getData().isAfter(hoje))
                .count();
    }

    /** Conta quantas presenças o aluno tem em uma aula específica. */
    public long presencasNaAula(int aulaId) {
        return presencas.stream()
                .filter(p -> p.getAulaId() == aulaId)
                .count();
    }

    public boolean temBaixaFrequencia(LocalDate hoje) {
        return presencasNosUltimos30Dias(hoje) < MINIMO_PRESENCAS_30_DIAS;
    }

    // ---------- Avaliações e histórico ----------

    public void adicionarAvaliacao(AvaliacaoFisica avaliacao) {
        avaliacoes.add(Objects.requireNonNull(avaliacao));
        avaliacoes.sort(Comparator.comparing(AvaliacaoFisica::getData));
    }

    public List<AvaliacaoFisica> getAvaliacoes() {
        return Collections.unmodifiableList(avaliacoes);
    }

    public void adicionarRegistro(RegistroTreino registro) {
        historico.add(Objects.requireNonNull(registro));
        historico.sort(Comparator.comparing(RegistroTreino::getData));
    }

    public List<RegistroTreino> getHistorico() {
        return Collections.unmodifiableList(historico);
    }
}
