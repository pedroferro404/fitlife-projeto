package fitlife.excecao;

/** Lançada quando a entrada padrão é fechada (Ctrl+D / Ctrl+Z). Permite sair salvando os dados. */
public class EntradaEncerradaException extends RuntimeException {

    public EntradaEncerradaException() {
        super("Entrada encerrada pelo usuário.");
    }
}
