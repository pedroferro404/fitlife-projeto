package fitlife.excecao;

/** Lançada quando um registro (aluno, aula, equipamento...) não existe. */
public class NaoEncontradoException extends AcademiaException {

    public NaoEncontradoException(String entidade, int id) {
        super(entidade + " #" + id + " não encontrado(a).");
    }
}
