package fitlife;

import fitlife.persistencia.Persistencia;
import fitlife.servico.Academia;
import fitlife.ui.Menu;

import java.nio.file.Path;

/** Ponto de entrada: carrega os dados dos CSV, abre o menu e salva ao sair. */
public class Main {

    public static void main(String[] args) {
        Academia academia = new Academia();
        Persistencia persistencia = new Persistencia(Path.of("dados"), Path.of("relatorios"));
        persistencia.carregar(academia);
        try {
            new Menu(academia, persistencia).executar();
        } catch (RuntimeException e) {
            // Última barreira: mesmo num erro inesperado, os dados são salvos antes de sair.
            System.out.println("[ERRO INESPERADO] " + e.getMessage());
            persistencia.salvar(academia);
        }
    }
}
