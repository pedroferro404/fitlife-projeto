package fitlife.servico;

import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.PlanoAnual;
import fitlife.modelo.PlanoMensal;
import fitlife.modelo.PlanoVip;
import fitlife.modelo.TipoModalidade;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

/**
 * Popula a academia com dados realistas para a demonstração.
 * Usa os próprios serviços, então todas as regras de negócio são respeitadas.
 */
public class DadosExemplo {

    private final Academia academia;
    private final AulaService aulas;
    private final AlunoService alunos;
    private final EquipamentoService equipamentos;
    private final HistoricoService historico;
    private final FinanceiroService financeiro;

    public DadosExemplo(Academia academia, AulaService aulas, AlunoService alunos,
                        EquipamentoService equipamentos, HistoricoService historico, FinanceiroService financeiro) {
        this.academia = academia;
        this.aulas = aulas;
        this.alunos = alunos;
        this.equipamentos = equipamentos;
        this.historico = historico;
        this.financeiro = financeiro;
    }

    public void carregar() {
        academia.limpar();
        LocalDate hoje = LocalDate.now();

        // ----- Professores e aulas (requisito 1)
        int ana = aulas.cadastrarProfessor("Ana Souza", "(86) 99901-1001", TipoModalidade.YOGA).getId();
        int bruno = aulas.cadastrarProfessor("Bruno Lima", "(86) 99901-1002", TipoModalidade.MUSCULACAO).getId();
        int carla = aulas.cadastrarProfessor("Carla Mendes", "(86) 99901-1003", TipoModalidade.PILATES).getId();

        Aula yogaSeg = aulas.cadastrarAula(TipoModalidade.YOGA, ana, DayOfWeek.MONDAY, LocalTime.of(7, 0), 15, false);
        Aula muscSeg = aulas.cadastrarAula(TipoModalidade.MUSCULACAO, bruno, DayOfWeek.MONDAY, LocalTime.of(18, 0), 20, false);
        Aula pilatesTer = aulas.cadastrarAula(TipoModalidade.PILATES, carla, DayOfWeek.TUESDAY, LocalTime.of(8, 0), 3, false);
        Aula yogaQua = aulas.cadastrarAula(TipoModalidade.YOGA, ana, DayOfWeek.WEDNESDAY, LocalTime.of(19, 0), 15, false);
        Aula pilatesVip = aulas.cadastrarAula(TipoModalidade.PILATES, carla, DayOfWeek.FRIDAY, LocalTime.of(7, 0), 2, true);

        // ----- Alunos (requisito 2), matriculados há alguns meses
        LocalDate matricula = hoje.minusMonths(4).withDayOfMonth(1);
        Aluno marcos = alunos.cadastrarAluno("Marcos Vinícius", "(86) 98800-2001", new PlanoVip(), 5, matricula);
        Aluno juliana = alunos.cadastrarAluno("Juliana Alves", "(86) 98800-2002", new PlanoMensal(), 10, matricula);
        Aluno rafael = alunos.cadastrarAluno("Rafael Costa", "(86) 98800-2003", new PlanoAnual(), 5, matricula);
        Aluno beatriz = alunos.cadastrarAluno("Beatriz Rocha", "(86) 98800-2004", new PlanoVip(), 15, matricula);
        Aluno thiago = alunos.cadastrarAluno("Thiago Nunes", "(86) 98800-2005", new PlanoMensal(), 10, matricula);
        Aluno larissa = alunos.cadastrarAluno("Larissa Melo", "(86) 98800-2006", new PlanoVip(), 20, matricula);

        // Inscrições: Pilates de terça tem 3 vagas para mostrar a lista de espera com prioridade VIP
        aulas.inscrever(marcos.getId(), yogaSeg.getId());
        aulas.inscrever(marcos.getId(), muscSeg.getId());
        aulas.inscrever(marcos.getId(), pilatesVip.getId());
        aulas.inscrever(juliana.getId(), yogaSeg.getId());
        aulas.inscrever(juliana.getId(), pilatesTer.getId());
        aulas.inscrever(rafael.getId(), muscSeg.getId());
        aulas.inscrever(rafael.getId(), pilatesTer.getId());
        aulas.inscrever(beatriz.getId(), pilatesVip.getId());   // Pilates VIP fica lotado (2/2)
        aulas.inscrever(beatriz.getId(), pilatesTer.getId());   // Pilates terça fica lotado (3/3)
        aulas.inscrever(beatriz.getId(), yogaQua.getId());
        aulas.inscrever(thiago.getId(), muscSeg.getId());
        aulas.inscrever(thiago.getId(), pilatesTer.getId());    // vai para a lista de espera
        aulas.inscrever(larissa.getId(), pilatesTer.getId());   // VIP: passa à frente do Thiago na fila
        aulas.inscrever(larissa.getId(), yogaQua.getId());

        // Presenças nos últimos 30 dias (Rafael, Thiago e Larissa ficam com baixa frequência)
        registrarPresencas(marcos, hoje, 99);
        registrarPresencas(juliana, hoje, 99);
        registrarPresencas(beatriz, hoje, 99);
        registrarPresencas(rafael, hoje, 3);
        registrarPresencas(larissa, hoje, 2);

        // ----- Equipamentos e reservas (requisito 3)
        int esteira1 = equipamentos.cadastrar("Esteira 01").getId();
        int bike = equipamentos.cadastrar("Bicicleta ergométrica").getId();
        equipamentos.cadastrar("Leg press 45°");
        int remo = equipamentos.cadastrar("Remo ergômetro").getId();
        int esteira2 = equipamentos.cadastrar("Esteira 02").getId();
        equipamentos.enviarParaManutencao(remo);
        equipamentos.iniciarUso(esteira2);

        LocalDateTime amanha7h = hoje.plusDays(1).atTime(7, 0);
        equipamentos.reservar(marcos.getId(), esteira1, amanha7h, 60);
        equipamentos.reservar(beatriz.getId(), bike, amanha7h.plusMinutes(30), 45);
        equipamentos.reservar(beatriz.getId(), esteira1, amanha7h.plusMinutes(90), 30);

        // ----- Histórico e avaliações (requisito 4)
        historico.registrarAvaliacao(marcos.getId(), hoje.minusDays(90), 92.0, 28.0);
        historico.registrarAvaliacao(marcos.getId(), hoje.minusDays(45), 89.5, 25.5);
        historico.registrarAvaliacao(marcos.getId(), hoje.minusDays(5), 87.2, 23.1);
        historico.registrarAvaliacao(juliana.getId(), hoje.minusDays(60), 64.0, 30.0);
        historico.registrarAvaliacao(juliana.getId(), hoje.minusDays(3), 62.1, 27.4);
        historico.registrarAvaliacao(rafael.getId(), hoje.minusDays(20), 78.3, 21.0);
        historico.registrarTreino(marcos.getId(), hoje.minusDays(2), "Treino livre: peito e tríceps (supino 4x10 com 60 kg)");
        historico.registrarTreino(marcos.getId(), hoje.minusDays(1), "Treino livre: 30 min de esteira + abdominais");
        historico.registrarTreino(juliana.getId(), hoje.minusDays(4), "Treino livre: pernas (agachamento 4x12)");

        // ----- Pagamentos (requisito 5): mês passado todos pagaram (alguns atrasados)
        YearMonth atual = YearMonth.from(hoje);
        YearMonth anterior = atual.minusMonths(1);
        List<Aluno> todos = new ArrayList<>(List.of(marcos, juliana, rafael, beatriz, thiago, larissa));
        for (Aluno aluno : todos) {
            LocalDate venc = financeiro.vencimentoDe(aluno, anterior);
            int atraso = aluno == rafael ? 10 : aluno == thiago ? 5 : 0;
            financeiro.registrarPagamento(aluno.getId(), anterior, venc.plusDays(atraso));
        }
        // Mês atual: só alguns já pagaram (os outros aparecem em "pendências")
        for (Aluno aluno : List.of(marcos, juliana, beatriz)) {
            LocalDate venc = financeiro.vencimentoDe(aluno, atual);
            LocalDate data = venc.isAfter(hoje) ? hoje : venc;
            financeiro.registrarPagamento(aluno.getId(), atual, data);
        }
    }

    /** Registra presenças nos dias da semana das aulas em que o aluno está inscrito. */
    private void registrarPresencas(Aluno aluno, LocalDate hoje, int maximo) {
        int registradas = 0;
        for (int d = 0; d < 30 && registradas < maximo; d++) {
            LocalDate dia = hoje.minusDays(d);
            for (Aula aula : academia.aulasDoAluno(aluno)) {
                if (registradas < maximo && aula.isInscrito(aluno) && aula.getDiaSemana() == dia.getDayOfWeek()) {
                    alunos.registrarPresenca(aluno.getId(), aula.getId(), dia);
                    registradas++;
                }
            }
        }
    }
}
