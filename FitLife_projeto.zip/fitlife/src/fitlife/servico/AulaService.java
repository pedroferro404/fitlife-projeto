package fitlife.servico;

import fitlife.excecao.AcademiaException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.AulaVip;
import fitlife.modelo.Professor;
import fitlife.modelo.SituacaoInscricao;
import fitlife.modelo.TipoModalidade;
import fitlife.util.Formatos;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** Requisito 1: modalidades, horários, professores e inscrições em aulas. */
public class AulaService {

    private static final int MAX_VAGAS = 100;
    private final Academia academia;

    public AulaService(Academia academia) {
        this.academia = academia;
    }

    public Professor cadastrarProfessor(String nome, String telefone, TipoModalidade especialidade) {
        Professor professor = new Professor(academia.gerarId(Academia.PROFESSOR), nome, telefone, especialidade);
        academia.adicionarProfessor(professor);
        return professor;
    }

    public Aula cadastrarAula(TipoModalidade modalidade, int professorId, DayOfWeek dia,
                              LocalTime horario, int vagas, boolean exclusivaVip) {
        validarVagas(vagas);
        Professor professor = academia.buscarProfessor(professorId);
        verificarConflitoProfessor(professor, dia, horario, -1);

        int id = academia.gerarId(Academia.AULA);
        // POLIMORFISMO: o resto do sistema trata as duas como "Aula"
        Aula aula = exclusivaVip
                ? new AulaVip(id, modalidade, professor, dia, horario, vagas)
                : new Aula(id, modalidade, professor, dia, horario, vagas);
        academia.adicionarAula(aula);
        return aula;
    }

    public void editarAula(int aulaId, DayOfWeek dia, LocalTime horario, int vagas) {
        validarVagas(vagas);
        Aula aula = academia.buscarAula(aulaId);
        verificarConflitoProfessor(aula.getProfessor(), dia, horario, aulaId);
        aula.setLimiteVagas(vagas);
        aula.reagendar(dia, horario);
    }

    public void removerAula(int aulaId) {
        academia.removerAula(academia.buscarAula(aulaId));
    }

    /**
     * Inscreve o aluno respeitando o limite de modalidades do plano.
     * Entrar em outra turma de uma modalidade que ele já faz não conta como nova.
     */
    public SituacaoInscricao inscrever(int alunoId, int aulaId) {
        Aluno aluno = academia.buscarAluno(alunoId);
        Aula aula = academia.buscarAula(aulaId);

        Set<TipoModalidade> atuais = academia.modalidadesDoAluno(aluno);
        boolean modalidadeNova = !atuais.contains(aula.getModalidade());
        if (modalidadeNova && !aluno.getPlano().permiteQuantidadeModalidades(atuais.size() + 1)) {
            throw new AcademiaException("O plano " + aluno.getPlano().getNome() + " permite "
                    + aluno.getPlano().getDescricaoLimite() + ". " + aluno.getNome()
                    + " já faz " + atuais + ". Sugira o upgrade para o VIP.");
        }
        return aula.inscrever(aluno);
    }

    /** Devolve o aluno promovido da lista de espera (ou null). */
    public Aluno cancelarInscricao(int alunoId, int aulaId) {
        Aluno aluno = academia.buscarAluno(alunoId);
        Aula aula = academia.buscarAula(aulaId);
        return aula.remover(aluno);
    }

    public List<Aula> gradeOrdenada() {
        return academia.getAulas().stream()
                .sorted(Comparator.comparing(Aula::getDiaSemana).thenComparing(Aula::getHorario))
                .collect(Collectors.toList());
    }

    private void validarVagas(int vagas) {
        if (vagas < 1 || vagas > MAX_VAGAS) {
            throw new IllegalArgumentException("O número de vagas deve ser entre 1 e " + MAX_VAGAS + ".");
        }
    }

    private void verificarConflitoProfessor(Professor professor, DayOfWeek dia, LocalTime horario, int ignorarAulaId) {
        for (Aula outra : academia.getAulas()) {
            if (outra.getId() != ignorarAulaId && outra.getProfessor().equals(professor)
                    && outra.getDiaSemana() == dia && outra.getHorario().equals(horario)) {
                throw new AcademiaException(professor.getNome() + " já dá a aula #" + outra.getId() + " em "
                        + Formatos.diaSemana(dia) + " às " + Formatos.hora(horario) + ".");
            }
        }
    }
}
