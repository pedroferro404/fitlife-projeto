package fitlife.servico;

import fitlife.excecao.NaoEncontradoException;
import fitlife.modelo.Aluno;
import fitlife.modelo.Aula;
import fitlife.modelo.Equipamento;
import fitlife.modelo.Pagamento;
import fitlife.modelo.Professor;
import fitlife.modelo.Reserva;
import fitlife.modelo.TipoModalidade;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * "Banco de dados em memória" da academia: guarda todas as listas,
 * gera os IDs e faz as buscas. Os serviços usam esta classe;
 * a Persistencia salva e carrega o conteúdo dela em arquivos CSV.
 */
public class Academia {

    public static final String PROFESSOR = "professor";
    public static final String ALUNO = "aluno";
    public static final String AULA = "aula";
    public static final String EQUIPAMENTO = "equipamento";
    public static final String RESERVA = "reserva";
    public static final String PAGAMENTO = "pagamento";

    private final List<Professor> professores = new ArrayList<>();
    private final List<Aluno> alunos = new ArrayList<>();
    private final List<Aula> aulas = new ArrayList<>();
    private final List<Equipamento> equipamentos = new ArrayList<>();
    private final List<Reserva> reservas = new ArrayList<>();
    private final List<Pagamento> pagamentos = new ArrayList<>();
    private final Map<String, Integer> sequencias = new HashMap<>();

    // ---------- IDs ----------

    public int gerarId(String entidade) {
        int id = sequencias.getOrDefault(entidade, 1);
        sequencias.put(entidade, id + 1);
        return id;
    }

    /** Garante que IDs carregados do arquivo não sejam reutilizados. */
    private void registrarId(String entidade, int id) {
        sequencias.merge(entidade, id + 1, Math::max);
    }

    // ---------- Inclusão ----------

    public void adicionarProfessor(Professor p) {
        professores.add(p);
        registrarId(PROFESSOR, p.getId());
    }

    public void adicionarAluno(Aluno a) {
        alunos.add(a);
        registrarId(ALUNO, a.getId());
    }

    public void adicionarAula(Aula a) {
        aulas.add(a);
        registrarId(AULA, a.getId());
    }

    public void adicionarEquipamento(Equipamento e) {
        equipamentos.add(e);
        registrarId(EQUIPAMENTO, e.getId());
    }

    public void adicionarReserva(Reserva r) {
        reservas.add(r);
        registrarId(RESERVA, r.getId());
    }

    public void adicionarPagamento(Pagamento p) {
        pagamentos.add(p);
        registrarId(PAGAMENTO, p.getId());
    }

    // ---------- Remoção ----------

    public void removerAula(Aula aula) {
        aulas.remove(aula);
    }

    public void removerReserva(Reserva reserva) {
        reservas.remove(reserva);
    }

    /** Remove o aluno e tudo que depende dele (inscrições e reservas). Pagamentos ficam no histórico. */
    public void removerAluno(Aluno aluno) {
        for (Aula aula : aulas) {
            if (aula.contem(aluno)) {
                aula.remover(aluno);
            }
        }
        reservas.removeIf(r -> r.getAluno().equals(aluno));
        alunos.remove(aluno);
    }

    // ---------- Buscas ----------

    public Professor buscarProfessor(int id) {
        return professores.stream().filter(p -> p.getId() == id).findFirst()
                .orElseThrow(() -> new NaoEncontradoException("Professor", id));
    }

    public Aluno buscarAluno(int id) {
        return alunos.stream().filter(a -> a.getId() == id).findFirst()
                .orElseThrow(() -> new NaoEncontradoException("Aluno", id));
    }

    public Aula buscarAula(int id) {
        return aulas.stream().filter(a -> a.getId() == id).findFirst()
                .orElseThrow(() -> new NaoEncontradoException("Aula", id));
    }

    public Equipamento buscarEquipamento(int id) {
        return equipamentos.stream().filter(e -> e.getId() == id).findFirst()
                .orElseThrow(() -> new NaoEncontradoException("Equipamento", id));
    }

    public Reserva buscarReserva(int id) {
        return reservas.stream().filter(r -> r.getId() == id).findFirst()
                .orElseThrow(() -> new NaoEncontradoException("Reserva", id));
    }

    public List<Aula> aulasDoAluno(Aluno aluno) {
        return aulas.stream().filter(a -> a.contem(aluno)).collect(Collectors.toList());
    }

    /** Modalidades distintas em que o aluno está (inscrito ou na fila). */
    public Set<TipoModalidade> modalidadesDoAluno(Aluno aluno) {
        Set<TipoModalidade> modalidades = EnumSet.noneOf(TipoModalidade.class);
        for (Aula aula : aulasDoAluno(aluno)) {
            modalidades.add(aula.getModalidade());
        }
        return modalidades;
    }

    public boolean isVazia() {
        return professores.isEmpty() && alunos.isEmpty() && aulas.isEmpty()
                && equipamentos.isEmpty() && pagamentos.isEmpty();
    }

    public void limpar() {
        professores.clear();
        alunos.clear();
        aulas.clear();
        equipamentos.clear();
        reservas.clear();
        pagamentos.clear();
        sequencias.clear();
    }

    // ---------- Getters somente-leitura ----------

    public List<Professor> getProfessores() {
        return Collections.unmodifiableList(professores);
    }

    public List<Aluno> getAlunos() {
        return Collections.unmodifiableList(alunos);
    }

    public List<Aula> getAulas() {
        return Collections.unmodifiableList(aulas);
    }

    public List<Equipamento> getEquipamentos() {
        return Collections.unmodifiableList(equipamentos);
    }

    public List<Reserva> getReservas() {
        return Collections.unmodifiableList(reservas);
    }

    public List<Pagamento> getPagamentos() {
        return Collections.unmodifiableList(pagamentos);
    }
}
