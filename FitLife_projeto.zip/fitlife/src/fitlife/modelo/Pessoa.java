package fitlife.modelo;

/**
 * ABSTRAÇÃO: representa qualquer pessoa da academia.
 * Não pode ser instanciada diretamente; Aluno e Professor herdam dela.
 * ENCAPSULAMENTO: atributos privados, alterados só por setters que validam.
 */
public abstract class Pessoa {

    private final int id;
    private String nome;
    private String telefone;

    protected Pessoa(int id, String nome, String telefone) {
        this.id = id;
        setNome(nome);
        setTelefone(telefone);
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome não pode ficar vazio.");
        }
        this.nome = nome.trim();
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone == null ? "" : telefone.trim();
    }

    /** POLIMORFISMO: cada subclasse descreve seu próprio papel na academia. */
    public abstract String getPapel();

    @Override
    public String toString() {
        return String.format("#%d %s - %s", id, nome, getPapel());
    }
}
