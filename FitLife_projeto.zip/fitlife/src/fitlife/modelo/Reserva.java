package fitlife.modelo;

import fitlife.util.Formatos;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Objects;

/** Reserva de equipamento por um aluno VIP, por no máximo 1 hora. */
public class Reserva {

    public static final int DURACAO_MAXIMA_MINUTOS = 60;

    private final int id;
    private final Equipamento equipamento;
    private final Aluno aluno;
    private final LocalDateTime inicio;
    private final LocalDateTime fim;

    public Reserva(int id, Equipamento equipamento, Aluno aluno, LocalDateTime inicio, LocalDateTime fim) {
        this.id = id;
        this.equipamento = Objects.requireNonNull(equipamento);
        this.aluno = Objects.requireNonNull(aluno);
        this.inicio = Objects.requireNonNull(inicio);
        this.fim = Objects.requireNonNull(fim);
        if (!fim.isAfter(inicio)) {
            throw new IllegalArgumentException("O fim da reserva deve ser depois do início.");
        }
        if (getDuracaoMinutos() > DURACAO_MAXIMA_MINUTOS) {
            throw new IllegalArgumentException("A reserva pode durar no máximo " + DURACAO_MAXIMA_MINUTOS + " minutos.");
        }
    }

    /** Dois intervalos se cruzam quando um começa antes do outro terminar. */
    public boolean conflitaCom(LocalDateTime outroInicio, LocalDateTime outroFim) {
        return outroInicio.isBefore(fim) && outroFim.isAfter(inicio);
    }

    public long getDuracaoMinutos() {
        return Duration.between(inicio, fim).toMinutes();
    }

    public int getId() {
        return id;
    }

    public Equipamento getEquipamento() {
        return equipamento;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public LocalDateTime getInicio() {
        return inicio;
    }

    public LocalDateTime getFim() {
        return fim;
    }

    @Override
    public String toString() {
        return String.format("#%d %-20s %s  %s até %s (%d min)", id, equipamento.getNome(), aluno.getNome(),
                Formatos.dataHora(inicio), Formatos.hora(fim.toLocalTime()), getDuracaoMinutos());
    }
}
