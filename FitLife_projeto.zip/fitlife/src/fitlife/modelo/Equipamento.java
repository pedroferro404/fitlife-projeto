package fitlife.modelo;

import fitlife.excecao.AcademiaException;

/**
 * Equipamento da academia. O status só muda pelos métodos abaixo,
 * que impedem transições inválidas (ex.: usar um aparelho em manutenção).
 */
public class Equipamento {

    private final int id;
    private String nome;
    private StatusEquipamento status;

    public Equipamento(int id, String nome, StatusEquipamento status) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("O nome do equipamento não pode ficar vazio.");
        }
        this.id = id;
        this.nome = nome.trim();
        this.status = status == null ? StatusEquipamento.DISPONIVEL : status;
    }

    public void iniciarUso() {
        if (status != StatusEquipamento.DISPONIVEL) {
            throw new AcademiaException(nome + " não está disponível (status: " + status + ").");
        }
        status = StatusEquipamento.EM_USO;
    }

    public void finalizarUso() {
        if (status != StatusEquipamento.EM_USO) {
            throw new AcademiaException(nome + " não está em uso.");
        }
        status = StatusEquipamento.DISPONIVEL;
    }

    public void enviarParaManutencao() {
        if (status == StatusEquipamento.EM_MANUTENCAO) {
            throw new AcademiaException(nome + " já está em manutenção.");
        }
        status = StatusEquipamento.EM_MANUTENCAO;
    }

    public void concluirManutencao() {
        if (status != StatusEquipamento.EM_MANUTENCAO) {
            throw new AcademiaException(nome + " não está em manutenção.");
        }
        status = StatusEquipamento.DISPONIVEL;
    }

    public boolean isEmManutencao() {
        return status == StatusEquipamento.EM_MANUTENCAO;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public StatusEquipamento getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return String.format("#%d %-22s %s", id, nome, status);
    }
}
