package fitlife.modelo;

import fitlife.util.Formatos;

/**
 * ABSTRAÇÃO + POLIMORFISMO: cada tipo de plano define seu valor e seu limite
 * de modalidades. O resto do sistema só conversa com "Plano", sem saber
 * qual é o tipo concreto. Para criar um plano novo, basta outra subclasse.
 */
public abstract class Plano {

    public static final int ILIMITADO = Integer.MAX_VALUE;

    /** Código usado para salvar em arquivo (MENSAL, ANUAL, VIP). */
    public abstract String getCodigo();

    public abstract String getNome();

    public abstract double getValorMensal();

    public abstract int getLimiteModalidades();

    /** Por padrão o plano não é VIP; PlanoVip sobrescreve. */
    public boolean isVip() {
        return false;
    }

    public boolean permiteQuantidadeModalidades(int quantidade) {
        return quantidade <= getLimiteModalidades();
    }

    public String getDescricaoLimite() {
        return getLimiteModalidades() == ILIMITADO
                ? "modalidades ilimitadas"
                : "até " + getLimiteModalidades() + " modalidades";
    }

    /** Fábrica: converte o código salvo no arquivo no objeto certo. */
    public static Plano criar(String codigo) {
        switch (codigo.trim().toUpperCase()) {
            case "MENSAL":
                return new PlanoMensal();
            case "ANUAL":
                return new PlanoAnual();
            case "VIP":
                return new PlanoVip();
            default:
                throw new IllegalArgumentException("Plano desconhecido: " + codigo);
        }
    }

    public static Plano[] todos() {
        return new Plano[] {new PlanoMensal(), new PlanoAnual(), new PlanoVip()};
    }

    @Override
    public String toString() {
        return getNome() + " - " + Formatos.moeda(getValorMensal()) + "/mês, " + getDescricaoLimite();
    }
}
