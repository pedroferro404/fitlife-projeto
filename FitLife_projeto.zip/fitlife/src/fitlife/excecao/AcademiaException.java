package fitlife.excecao;

/**
 * Exceção base para qualquer violação de regra de negócio da academia
 * (turma lotada, plano sem permissão, conflito de horário etc.).
 * É "unchecked" para não poluir as assinaturas, mas é sempre tratada no menu.
 */
public class AcademiaException extends RuntimeException {

    public AcademiaException(String mensagem) {
        super(mensagem);
    }
}
