# FitLife – Sistema de Gestão de Academia

Trabalho da P2 de Programação Orientada a Objetos (Java). Sistema de console para a academia
FitLife: aulas e horários, professores, alunos e planos, frequência, equipamentos e reservas,
histórico e avaliações físicas, pagamentos com multa e relatórios de receita.

## Requisitos

- Java JDK 17 ou superior (testado com JDK 21)
- Nenhuma biblioteca externa

## Como executar

Na pasta do projeto (a que contém `src/`):

```bash
# 1. Compilar
javac -encoding UTF-8 -d out $(find src -name "*.java")

# 2. Executar
java -cp out fitlife.Main
```

No Windows (PowerShell):

```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
java -cp out fitlife.Main
```

No IntelliJ/Eclipse: abra a pasta, marque `src` como Sources Root e execute `fitlife.Main`.

Dica: na primeira execução use a opção **6 – Carregar dados de exemplo** para ter alunos,
aulas, reservas e pagamentos prontos para a demonstração.

## Onde ficam os dados

- `dados/*.csv` – todos os cadastros (criados automaticamente, separador `;`)
- `relatorios/*.txt` – relatórios de evolução e de receita gerados pelo sistema

Se a pasta `dados/` não existir o sistema começa vazio; linhas corrompidas nos CSV são ignoradas com aviso.

## Estrutura

```
src/fitlife/
  Main.java                 ponto de entrada
  modelo/                   classes de domínio (Pessoa, Aluno, Professor, Plano..., Aula, AulaVip...)
  servico/                  regras de negócio (um serviço por requisito) + Academia (dados em memória)
  persistencia/             leitura/gravação dos CSV e relatórios
  ui/                       menu e leitura segura do teclado
  excecao/                  exceções do sistema
  util/                     formatação de datas e valores
```

## Regras implementadas

| Requisito | Onde |
|---|---|
| Cadastro de aulas (Yoga, Musculação, Pilates), horários, professores, vagas | `AulaService` |
| Aula especial só para VIP; VIP fura a fila na lista de espera | `AulaVip`, `Aula.inscrever` |
| Planos Mensal (R$120, 2 modalidades), Anual (R$100, 2), VIP (R$200, ilimitado) | `Plano` e subclasses |
| Presença e alerta de menos de 8 presenças em 30 dias | `AlunoService`, `Aluno` |
| Equipamentos: disponível / em uso / em manutenção | `Equipamento` |
| Reserva só VIP, até 1 hora, sem conflito de horário | `EquipamentoService.reservar` |
| Histórico, avaliações (peso e % gordura) e relatório de evolução | `HistoricoService` |
| Pagamento com multa de 2% + 0,1% ao dia | `Pagamento.calcularMulta` |
| Relatório de receita por plano e por modalidade | `FinanceiroService.relatorioReceita` |
